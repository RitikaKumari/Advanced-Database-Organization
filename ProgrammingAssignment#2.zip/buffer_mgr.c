//
//  buffer_mgr.c
//  Assignment 1
//
//  Created by Viraj Desai on 3/14/18.
//  Copyright © 2018 Viraj Desai. All rights reserved.
//

#include "buffer_mgr.h"
#include <stdio.h>
#include <stdlib.h>
#include "storage_mgr.h"
#include "dberror.h"
#include "dt.h"

/*********************Variable declaration*********************/
// Page Frame declaration.
typedef struct frame{
    int frameNumber,fixCount,totalReadSinglePage,totalWriteSinglePage,count,lfuCount;
    struct frame *previousFrame, *nextFrame;
    struct BM_PageHandle *pageFrameInfo;
    bool dirtyFlag;
} frame;

// Total number of pages read or write on the buffer pool.
int totalReadPage, totalWritePage;

// Queue declaration
typedef struct queue{
    int queueSize;
    struct frame *head, *current, *tail;
}queue;

// File hadnler declaration
SM_FileHandle *fHandle;
/****************************************************************/

/*************************************************************************
 * Method Name: initBufferPool
 *
 * Description: Initializing a buffer pool i.e. initializing all the pointers and varaibles.
 *
 * Parameter: BM_BufferPool *const bm = Buffer Pool Handler,
 *            const char *const pageFileName = Page File (Disk FIle) name pointer,
 *            const int numPages = Number of pages a buffer pool should have,
 *            ReplacementStrategy strategy = Replacement Startegy used for replacing the pool content
 *            void *stratData = Not Applicable
 
 * Return: RC code
 
 * Language: C
 *************************************************************************/
RC initBufferPool(BM_BufferPool *const bm, const char *const pageFileName,
                  const int numPages, ReplacementStrategy strategy,
                  void *stratData)
{
    char * pf=(char*)pageFileName;
    //Check whether buffer pool is addressing to memory or not.
    if(bm==NULL)
    {
        RC_message="Buffer Pool memory is not allocated!";
        return RC_BUFFER_POOL_FAILED;
    }
    //Check whether page file is available on disk or not.
    else if(pf==NULL)
    {
        RC_message="File not found!";
        return RC_FILE_NOT_FOUND;
    }
    //Check for number of pages requested by the buffer manager client to be loaded into the buffer pool.
    else if(numPages==0 || numPages<0)
    {
        RC_message="No pages or incorrect pages!";
        return RC_NO_PAGES;
    }
    else
    {
        bm->pageFile=pf;
        bm->numPages=numPages;
        bm->strategy=strategy;
        totalReadPage=0;
        totalWritePage=0;
        frame *f[bm->numPages];
        int i=0;
        while (i< bm->numPages)
        {
            f[i] = (frame*) malloc(sizeof(frame));
            f[i]->pageFrameInfo = MAKE_PAGE_HANDLE();
            f[i]->pageFrameInfo->pageNum=NO_PAGE;
            f[i]->pageFrameInfo->data=(char*)malloc(sizeof(char)*PAGE_SIZE);
            f[i]->frameNumber=i;
            f[i]->fixCount=0;
            f[i]->totalReadSinglePage=0;
            f[i]->totalWriteSinglePage=0;
            f[i]->dirtyFlag=FALSE;
            f[i]->count=0;
            f[i]->lfuCount=0;
            if(i==0)
            {
                f[i]->nextFrame=NULL;
                f[i]->previousFrame=NULL;
            }
            if(i>0)
            {
                f[i]->previousFrame=f[i-1];
                f[i-1]->nextFrame=f[i];
                f[i]->nextFrame=NULL;
            }
            
            i++;
        }
        queue *listQueue= (queue*) malloc (sizeof(queue));
        bm->mgmtData=listQueue;
        listQueue->head=listQueue->tail=listQueue->current=f[0];
        listQueue->queueSize=0;
        fHandle=(SM_FileHandle*) malloc(sizeof(SM_FileHandle));
        RC_message="Buffer Pool initialized successfully!";
        return RC_OK;
    }
}
/*Search Page*/
extern RC seekPage(BM_BufferPool *const bm, BM_PageHandle *const page, const PageNumber pageNum)
{
    queue *listQueue=(queue*) bm->mgmtData;
    if(listQueue->queueSize==0)
    {
        return RC_NO_PAGES;
    }
    if(listQueue->queueSize>0)
    {
        for(listQueue->current=listQueue->head;listQueue->current!=listQueue->tail;
            listQueue->current=listQueue->current->nextFrame)
        {
            if(listQueue->current->pageFrameInfo->pageNum==pageNum)
            {
                page->pageNum=pageNum;
                page->data=listQueue->current->pageFrameInfo->data;
                return RC_OK;
            }
        }
        if(listQueue->current==listQueue->tail && listQueue->current->pageFrameInfo->pageNum==pageNum)
        {
            page->pageNum=pageNum;
            page->data=listQueue->current->pageFrameInfo->data;
            return RC_OK;
        }
    }
    return RC_NA;
}
/*Increase Capacity*/
extern RC increaseCapacity(BM_BufferPool *const bm, BM_PageHandle *const page, const PageNumber pageNum)
{
    //int totalDiskPage=fHandle->totalNumPages;
    RC RC_Ensure=ensureCapacity(pageNum+1, fHandle);
    if(RC_Ensure!=RC_OK)
    {
        return RC_NA;
    }
    //int addedPageCount=(pageNum+1)-totalDiskPage;
    //totalWritePage+=addedPageCount;
    return RC_OK;
}
/* Implementation of FIFO replacement strategy. */
RC FIFO_Strategy(BM_BufferPool *const bm, BM_PageHandle *const page,
                 const PageNumber pageNum)
{
    if(bm==NULL)
    {
        return RC_BUFFER_POOL_FAILED;
    }
    if(page==NULL)
    {
        return RC_BUFFER_POOL_HANDLE_NOT_INIT;
    }
    if(pageNum<0)
    {
        return RC_NO_PAGES;
    }
    //search wether requested page is already present in the queue or not.
    queue *listQueue=(queue*)bm->mgmtData;
    //====================================
    //count: search for the maximum count
    int maxCount=listQueue->head->count;
    for(listQueue->current=listQueue->head;listQueue->current!=listQueue->tail;
        listQueue->current=listQueue->current->nextFrame)
    {
        if(maxCount<listQueue->current->nextFrame->count)
        {
            maxCount=listQueue->current->nextFrame->count;
        }
    }
    if(listQueue->current==listQueue->tail && maxCount<listQueue->tail->count)
    {
        maxCount=listQueue->tail->count;
    }
    //=====================================
    RC RC_Seek=seekPage(bm, page, pageNum);
    if(RC_Seek==RC_OK)
    {
        //increase fix count
        listQueue->current->fixCount+=1;
        //update count
        listQueue->current->count=maxCount+1;
        listQueue->current->lfuCount=(listQueue->current->lfuCount)+1;
        return RC_SEEK_SUCCESS;
    }
    if(RC_Seek==RC_NO_PAGES || RC_Seek==RC_NA)
    {
        //check whether requested pageNum is available in the disk or not.
        //error
        RC RC_Open=openPageFile(bm->pageFile, fHandle);
        if(RC_Open!=RC_OK)
        {
            closePageFile(fHandle);
            return RC_NA;
        }
        if(fHandle->totalNumPages<pageNum+1)
        {
            RC RC_Increase=increaseCapacity(bm,page,pageNum);
            if(RC_Increase!=RC_OK)
            {
                closePageFile(fHandle);
                return RC_NA;
            }
        }
        //queue is empty then read the page from the disk to queue's head.
        if(listQueue->queueSize==0)
        {
            listQueue->current->fixCount++;
            listQueue->current->totalReadSinglePage=1;
            RC RC_Read=readBlock(pageNum, fHandle, listQueue->current->pageFrameInfo->data);
            totalReadPage++;
            totalWritePage=0;
            if(RC_Read!=RC_OK)
            {
                closePageFile(fHandle);
                return RC_NA;
            }
            else
            {
                closePageFile(fHandle);
                listQueue->current->totalReadSinglePage=0;
                listQueue->current->dirtyFlag=FALSE;
                listQueue->current->pageFrameInfo->pageNum=pageNum;
                //listQueue->current->nextFrame=NULL;
                //count
                listQueue->current->count=1;
                listQueue->current->lfuCount=1;
                listQueue->queueSize=listQueue->queueSize+1;
                page->pageNum=pageNum;
                page->data=listQueue->current->pageFrameInfo->data;
                return RC_OK;
            }
        }
        if(listQueue->queueSize!=0 && listQueue->queueSize<bm->numPages)
        {
            //====================================
            //count: search for the maximum count
            int maxCount=listQueue->head->count;
            for(listQueue->current=listQueue->head;listQueue->current!=listQueue->tail;
                listQueue->current=listQueue->current->nextFrame)
            {
                if(maxCount<listQueue->current->nextFrame->count)
                {
                    maxCount=listQueue->current->nextFrame->count;
                }
            }
            if(listQueue->current==listQueue->tail && maxCount<listQueue->tail->count)
            {
                maxCount=listQueue->tail->count;
            }
            //=====================================
            //read disk's page to the tail of the queue.
            listQueue->tail->nextFrame->fixCount++;
            listQueue->tail->nextFrame->totalReadSinglePage=1;
            RC RC_Read=readBlock(pageNum, fHandle, listQueue->tail->nextFrame->pageFrameInfo->data);
            totalReadPage++;
            totalWritePage=0;
            if(RC_Read!=RC_OK)
            {
                closePageFile(fHandle);
                return RC_NA;
            }
            else
            {
                closePageFile(fHandle);
                listQueue->tail->nextFrame->totalReadSinglePage=0;
                listQueue->tail->nextFrame->dirtyFlag=FALSE;
                listQueue->tail->nextFrame->pageFrameInfo->pageNum=pageNum;
                listQueue->tail=listQueue->tail->nextFrame;
                listQueue->current=listQueue->tail;
                //assign count
                listQueue->current->count=maxCount+1;
                listQueue->current->lfuCount=1;
                //listQueue->current=NULL;
                listQueue->queueSize=listQueue->queueSize+1;
                page->pageNum=pageNum;
                page->data=listQueue->current->pageFrameInfo->data;
                return RC_OK;
            }
        }
        /*No space in queue to read disk file page. replace the first entered page having fix count=0 or totalReadSinglePage!=0 or totalWriteSinglePage !=0 by read data from the disk.*/
        if(listQueue->queueSize!=0 && listQueue->queueSize>=bm->numPages)
        {
            //====================================
            //count: search for the maximum count
            int maxCount=listQueue->head->count;
            for(listQueue->current=listQueue->head;listQueue->current!=listQueue->tail;
                listQueue->current=listQueue->current->nextFrame)
            {
                if(maxCount<listQueue->current->nextFrame->count)
                {
                    maxCount=listQueue->current->nextFrame->count;
                }
            }
            if(listQueue->current==listQueue->tail && maxCount<listQueue->tail->count)
            {
                maxCount=listQueue->tail->count;
            }
            //=====================================
            //need 1 node whose dirty flag is true and fix count
            int smallest=listQueue->head->pageFrameInfo->pageNum;
            for(listQueue->current=listQueue->head;listQueue->current!=listQueue->tail;
                listQueue->current=listQueue->current->nextFrame)
            {
                if(smallest>listQueue->current->nextFrame->pageFrameInfo->pageNum &&
                   listQueue->current->nextFrame->fixCount==0)
                {
                    smallest=listQueue->current->nextFrame->pageFrameInfo->pageNum;
                    //current will be the smallest number
                }
            }
            for(listQueue->current=listQueue->head;listQueue->current!=listQueue->tail;
                listQueue->current=listQueue->current->nextFrame)
            {
                if(listQueue->current->pageFrameInfo->pageNum==smallest)
                {
                    //write and then replace i.e. read
                    listQueue->current->totalWriteSinglePage=1;
                    //If page need to be replaced found then first write it in disk.
                    RC RC_Write=writeBlock(listQueue->current->pageFrameInfo->pageNum, fHandle,
                                           listQueue->current->pageFrameInfo->data);
                    //writing is performed when actually page in queue is modified then write on disk or else directly load new page in queue.
                    if(listQueue->current->dirtyFlag==TRUE)
                    {
                        totalWritePage++;
                    }
                    if(RC_Write!=RC_OK)
                    {
                        closePageFile(fHandle);
                        RC_NA;
                    }
                    listQueue->current->totalWriteSinglePage=0;
                    //replace the page in middle i.e. read the disk page into the queue's current.
                    listQueue->current->fixCount++;
                    listQueue->current->totalReadSinglePage=1;
                    RC RC_Read=readBlock(pageNum, fHandle, listQueue->current->pageFrameInfo->data);
                    totalReadPage++;
                    if(RC_Read!=RC_OK)
                    {
                        closePageFile(fHandle);
                        return RC_NA;
                    }
                    //after reading close the file.
                    closePageFile(fHandle);
                    listQueue->current->totalReadSinglePage=0;
                    listQueue->current->dirtyFlag=FALSE;
                    //assign count
                    listQueue->current->count=maxCount+1;
                    //listQueue->current->lfuCount=1;
                    listQueue->current->pageFrameInfo->pageNum=pageNum;
                    //move page to tail
                    //if current page is not head
                    /*if(listQueue->current!=listQueue->head)
                     {
                     listQueue->current->previousFrame->nextFrame=listQueue->current->nextFrame;
                     listQueue->current->nextFrame->previousFrame=listQueue->current->previousFrame;
                     listQueue->current->previousFrame=listQueue->tail;
                     listQueue->tail->nextFrame=listQueue->current;
                     listQueue->current->nextFrame=NULL;
                     listQueue->tail=listQueue->tail->nextFrame;
                     listQueue->queueSize+=1;
                     }
                     //if current page is head
                     if(listQueue->current==listQueue->head)
                     {
                     listQueue->head=listQueue->head->nextFrame;
                     listQueue->current->nextFrame->previousFrame=NULL;
                     listQueue->current->previousFrame=listQueue->tail;
                     listQueue->current->nextFrame=NULL;
                     listQueue->tail->nextFrame=listQueue->current;
                     listQueue->tail=listQueue->tail->nextFrame;
                     listQueue->queueSize+=1;
                     }
                     */
                    page->pageNum=pageNum;
                    page->data=listQueue->current->pageFrameInfo->data;
                    return RC_OK;
                }
            }
            if(listQueue->current==listQueue->tail && listQueue->current->pageFrameInfo->pageNum==smallest)
            {
                listQueue->current->totalWriteSinglePage=1;
                //If page need to be replaced found then first write it in disk.
                RC RC_Write=writeBlock(listQueue->current->pageFrameInfo->pageNum, fHandle,
                                       listQueue->current->pageFrameInfo->data);
                if(listQueue->current->dirtyFlag==TRUE)
                {
                    totalWritePage++;
                }
                if(RC_Write!=RC_OK)
                {
                    closePageFile(fHandle);
                    RC_NA;
                }
                listQueue->current->totalWriteSinglePage=0;
                //replace the page in middle i.e. read the disk page into the queue's current.
                listQueue->current->fixCount++;
                listQueue->current->totalReadSinglePage=1;
                RC RC_Read=readBlock(pageNum, fHandle, listQueue->current->pageFrameInfo->data);
                totalReadPage++;
                if(RC_Read!=RC_OK)
                {
                    closePageFile(fHandle);
                    return RC_NA;
                }
                //after reading close the file.
                closePageFile(fHandle);
                listQueue->current->totalReadSinglePage=0;
                listQueue->current->dirtyFlag=FALSE;
                //assign count
                listQueue->current->count=maxCount+1;
                listQueue->current->pageFrameInfo->pageNum=pageNum;
                //move page to tail
                //if current page is not head
                /*if(listQueue->current!=listQueue->head)
                 {
                 listQueue->current->previousFrame->nextFrame=listQueue->current->nextFrame;
                 listQueue->current->nextFrame->previousFrame=listQueue->current->previousFrame;
                 listQueue->current->previousFrame=listQueue->tail;
                 listQueue->tail->nextFrame=listQueue->current;
                 listQueue->current->nextFrame=NULL;
                 listQueue->tail=listQueue->tail->nextFrame;
                 listQueue->queueSize+=1;
                 }
                 //if current page is head
                 if(listQueue->current==listQueue->head)
                 {
                 listQueue->head=listQueue->head->nextFrame;
                 listQueue->current->nextFrame->previousFrame=NULL;
                 listQueue->current->previousFrame=listQueue->tail;
                 listQueue->current->nextFrame=NULL;
                 listQueue->tail->nextFrame=listQueue->current;
                 listQueue->tail=listQueue->tail->nextFrame;
                 listQueue->queueSize+=1;
                 }
                 */
                page->pageNum=pageNum;
                page->data=listQueue->current->pageFrameInfo->data;
                return RC_OK;
            }
            return RC_NA;//no cases suucessful
        }
    }
    return RC_NA; //no cases successful.
}
/* Implementation of LRU replacement strategy. */
RC LRU_Strategy(BM_BufferPool *const bm, BM_PageHandle *const page,
                 const PageNumber pageNum)
{
    queue *listQueue = (queue*) bm->mgmtData;
    if(listQueue->queueSize==0)
    {
        FIFO_Strategy(bm, page, pageNum);
        return RC_OK;
    }
    if(listQueue->queueSize!=0 && listQueue->queueSize<bm->numPages)
    {
        FIFO_Strategy(bm, page, pageNum);
        return RC_OK;
    }
    if(listQueue->queueSize!=0 && listQueue->queueSize>=bm->numPages)
    {
        //====================================
        //count: search for the maximum and minimum count of page.
        int maxCount=listQueue->head->count;
        int minCount=listQueue->head->count;
        //get max count
        for(listQueue->current=listQueue->head;listQueue->current!=listQueue->tail;
            listQueue->current=listQueue->current->nextFrame)
        {
            if(maxCount<listQueue->current->nextFrame->count)
            {
                maxCount=listQueue->current->nextFrame->count;
            }
        }
        if(listQueue->current==listQueue->tail && maxCount<listQueue->tail->count)
        {
            maxCount=listQueue->tail->count;
        }
        //get min count
        for(listQueue->current=listQueue->head;listQueue->current!=listQueue->tail;
            listQueue->current=listQueue->current->nextFrame)
        {
            if(minCount>listQueue->current->nextFrame->count)
            {
                minCount=listQueue->current->nextFrame->count;
            }
        }
        if(listQueue->current==listQueue->tail && minCount>listQueue->tail->count)
        {
            minCount=listQueue->tail->count;
        }
        //=====================================
        //search wether page is already present or not.
        RC RC_Search=seekPage(bm, page, pageNum);
        if(RC_Search==RC_OK)
        {
            //page->pageNum=listQueue->current->pageFrameInfo->pageNum;
            //page->data=listQueue->current->pageFrameInfo->data;
            listQueue->current->count=maxCount+1;
            listQueue->current->fixCount+=1;
        }
        //Search is unsuccessful
        if(RC_Search==RC_NA)
        {
            //replace page whose count is minimum and update its count to count of that page + maximum count got.
            for(listQueue->current=listQueue->head;listQueue->current!=listQueue->tail;
                listQueue->current=listQueue->current->nextFrame)
            {
                if(listQueue->current->count==minCount)
                {
                    //write old content to disk
                    //read another page from the disk to pool.
                    listQueue->current->totalWriteSinglePage=1;
                    //If page need to be replaced found then first write it in disk.
                    RC RC_Write=writeBlock(listQueue->current->pageFrameInfo->pageNum, fHandle,
                                           listQueue->current->pageFrameInfo->data);
                    //writing is performed when actually page in queue is modified then write on disk or else directly load new page in queue.
                    if(listQueue->current->dirtyFlag==TRUE)
                    {
                        totalWritePage++;
                    }
                    if(RC_Write!=RC_OK)
                    {
                        closePageFile(fHandle);
                        RC_NA;
                    }
                    listQueue->current->totalWriteSinglePage=0;
                    //replace the page in middle i.e. read the disk page into the queue's current.
                    listQueue->current->fixCount++;
                    listQueue->current->totalReadSinglePage=1;
                    RC RC_Read=readBlock(pageNum, fHandle, listQueue->current->pageFrameInfo->data);
                    totalReadPage++;
                    if(RC_Read!=RC_OK)
                    {
                        closePageFile(fHandle);
                        return RC_NA;
                    }
                    //after reading close the file.
                    closePageFile(fHandle);
                    listQueue->current->totalReadSinglePage=0;
                    listQueue->current->dirtyFlag=FALSE;
                    //assign count
                    listQueue->current->count=maxCount+1;
                    listQueue->current->pageFrameInfo->pageNum=pageNum;
                    page->pageNum=pageNum;
                    page->data=listQueue->current->pageFrameInfo->data;
                }
            }
            if(listQueue->current==listQueue->tail && listQueue->current->count==minCount)
            {
                listQueue->current->totalWriteSinglePage=1;
                //If page need to be replaced found then first write it in disk.
                RC RC_Write=writeBlock(listQueue->current->pageFrameInfo->pageNum, fHandle,
                                       listQueue->current->pageFrameInfo->data);
                if(listQueue->current->dirtyFlag==TRUE)
                {
                    totalWritePage++;
                }
                if(RC_Write!=RC_OK)
                {
                    closePageFile(fHandle);
                    RC_NA;
                }
                listQueue->current->totalWriteSinglePage=0;
                //replace the page in middle i.e. read the disk page into the queue's current.
                listQueue->current->fixCount++;
                listQueue->current->totalReadSinglePage=1;
                RC RC_Read=readBlock(pageNum, fHandle, listQueue->current->pageFrameInfo->data);
                totalReadPage++;
                if(RC_Read!=RC_OK)
                {
                    closePageFile(fHandle);
                    return RC_NA;
                }
                //after reading close the file.
                closePageFile(fHandle);
                listQueue->current->totalReadSinglePage=0;
                listQueue->current->dirtyFlag=FALSE;
                //assign count
                listQueue->current->count=maxCount+1;
                listQueue->current->pageFrameInfo->pageNum=pageNum;
                page->pageNum=pageNum;
                page->data=listQueue->current->pageFrameInfo->data;
            }
        }
        return RC_LRU_SUCCESS;//main if case return
    }
    return RC_NA; //no case suucessful.
}
/* Implementation of LFU replacement strategy. */
RC LFU_Strategy(BM_BufferPool *const bm, BM_PageHandle *const page,
                const PageNumber pageNum)
{
    queue *listQueue = (queue*) bm->mgmtData;
    if(listQueue->queueSize==0)
    {
        FIFO_Strategy(bm, page, pageNum);
        return RC_OK;
    }
    if(listQueue->queueSize!=0 && listQueue->queueSize<bm->numPages)
    {
        FIFO_Strategy(bm, page, pageNum);
        return RC_OK;
    }
    if(listQueue->queueSize!=0 && listQueue->queueSize>=bm->numPages)
    {
        //=======least frequent count=======
        int fcount=listQueue->head->lfuCount;
        for(listQueue->current=listQueue->head;listQueue->current!=listQueue->tail;
            listQueue->current=listQueue->current->nextFrame)
        {
            if(fcount>listQueue->current->nextFrame->lfuCount)
            {
                fcount=listQueue->current->nextFrame->lfuCount;
            }
        }
        if(listQueue->current==listQueue->tail && listQueue->current->lfuCount<fcount)
        {
            fcount=listQueue->current->lfuCount;
        }
        //====================================
        //====================================
        //count: search for the maximum and minimum count of page.
        int maxCount=listQueue->head->count;
        int minCount=listQueue->head->count;
        //get max count
        for(listQueue->current=listQueue->head;listQueue->current!=listQueue->tail;
            listQueue->current=listQueue->current->nextFrame)
        {
            if(maxCount<listQueue->current->nextFrame->count)
            {
                maxCount=listQueue->current->nextFrame->count;
            }
        }
        if(listQueue->current==listQueue->tail && maxCount<listQueue->tail->count)
        {
            maxCount=listQueue->tail->count;
        }
        //get min count
        for(listQueue->current=listQueue->head;listQueue->current!=listQueue->tail &&
            listQueue->current->lfuCount==fcount;
            listQueue->current=listQueue->current->nextFrame)
        {
            if(minCount>listQueue->current->nextFrame->count && listQueue->current->nextFrame->lfuCount==fcount)
            {
                minCount=listQueue->current->nextFrame->count;
            }
        }
        if(listQueue->current==listQueue->tail && listQueue->current->lfuCount==fcount &&
           minCount>listQueue->tail->count)
        {
            minCount=listQueue->tail->count;
        }
        //=====================================

        //search wether page is already present or not.
        RC RC_Search=seekPage(bm, page, pageNum);
        if(RC_Search==RC_OK)
        {
            //page->pageNum=listQueue->current->pageFrameInfo->pageNum;
            //page->data=listQueue->current->pageFrameInfo->data;
            listQueue->current->count=maxCount+1;
            listQueue->current->lfuCount=(listQueue->current->lfuCount)+1;
            listQueue->current->fixCount+=1;
        }
        //Search is unsuccessful
        if(RC_Search==RC_NA)
        {
            //replace page whose count is minimum and update its count to count of that page + maximum count got.
            for(listQueue->current=listQueue->head;listQueue->current!=listQueue->tail;
                listQueue->current=listQueue->current->nextFrame)
            {
                if(listQueue->current->lfuCount==fcount && listQueue->current->count==minCount)
                {
                    //write old content to disk
                    //read another page from the disk to pool.
                    listQueue->current->totalWriteSinglePage=1;
                    //If page need to be replaced found then first write it in disk.
                    RC RC_Write=writeBlock(listQueue->current->pageFrameInfo->pageNum, fHandle,
                                           listQueue->current->pageFrameInfo->data);
                    //writing is performed when actually page in queue is modified then write on disk or else directly load new page in queue.
                    if(listQueue->current->dirtyFlag==TRUE)
                    {
                        totalWritePage++;
                    }
                    if(RC_Write!=RC_OK)
                    {
                        closePageFile(fHandle);
                        RC_NA;
                    }
                    listQueue->current->totalWriteSinglePage=0;
                    //replace the page in middle i.e. read the disk page into the queue's current.
                    listQueue->current->fixCount++;
                    listQueue->current->totalReadSinglePage=1;
                    RC RC_Read=readBlock(pageNum, fHandle, listQueue->current->pageFrameInfo->data);
                    totalReadPage++;
                    if(RC_Read!=RC_OK)
                    {
                        closePageFile(fHandle);
                        return RC_NA;
                    }
                    //after reading close the file.
                    closePageFile(fHandle);
                    listQueue->current->totalReadSinglePage=0;
                    listQueue->current->dirtyFlag=FALSE;
                    //assign count
                    listQueue->current->count=maxCount+1;
                    listQueue->current->lfuCount=1;
                    listQueue->current->pageFrameInfo->pageNum=pageNum;
                    page->pageNum=pageNum;
                    page->data=listQueue->current->pageFrameInfo->data;
                }
            }
            if(listQueue->current==listQueue->tail && listQueue->current->lfuCount==fcount &&
               listQueue->current->count==minCount)
            {
                listQueue->current->totalWriteSinglePage=1;
                //If page need to be replaced found then first write it in disk.
                RC RC_Write=writeBlock(listQueue->current->pageFrameInfo->pageNum, fHandle,
                                       listQueue->current->pageFrameInfo->data);
                if(listQueue->current->dirtyFlag==TRUE)
                {
                    totalWritePage++;
                }
                if(RC_Write!=RC_OK)
                {
                    closePageFile(fHandle);
                    RC_NA;
                }
                listQueue->current->totalWriteSinglePage=0;
                //replace the page in middle i.e. read the disk page into the queue's current.
                listQueue->current->fixCount++;
                listQueue->current->totalReadSinglePage=1;
                RC RC_Read=readBlock(pageNum, fHandle, listQueue->current->pageFrameInfo->data);
                totalReadPage++;
                if(RC_Read!=RC_OK)
                {
                    closePageFile(fHandle);
                    return RC_NA;
                }
                //after reading close the file.
                closePageFile(fHandle);
                listQueue->current->totalReadSinglePage=0;
                listQueue->current->dirtyFlag=FALSE;
                //assign count
                listQueue->current->count=maxCount+1;
                listQueue->current->lfuCount=1;
                listQueue->current->pageFrameInfo->pageNum=pageNum;
                page->pageNum=pageNum;
                page->data=listQueue->current->pageFrameInfo->data;
            }
        }
        return RC_OK; //if passed.
    }
    return RC_NA; //no case successful.
}
/* Pinning a page. */
RC pinPage (BM_BufferPool *const bm, BM_PageHandle *const page,
            const PageNumber pageNum)
{
    if(bm->numPages == 0 || bm->numPages<0)
    {
        RC_message="No pages in the buffer pool or incorrect pages!";
        return RC_NO_PAGES;
    }
    else
    {
        //Check for blank pages are available in the buffer pool or not.
        switch (bm->strategy)
        {
            case RS_FIFO:
                FIFO_Strategy(bm,page,pageNum);
                break;
            case RS_LRU:
                LRU_Strategy(bm,page,pageNum);
                break;
            case RS_LFU:
                LFU_Strategy(bm,page,pageNum);
                break;
            default:
                printf("%i startegy is not implemented!", bm->strategy);
                break;
        }
        return RC_OK;
    }
}
/*Mark Dirty*/
RC markDirty (BM_BufferPool *const bm, BM_PageHandle *const page)
{
    queue *listQueue = (queue*) bm->mgmtData;
    //search the requested page in the PageList
    RC RC_Search = seekPage(bm,page,page->pageNum);
    // if something unexpected error happens or page not found, then return rc
    if (RC_Search != RC_OK)
    {
        return RC_NA;
    }
    else
    {
        // Now the current pointer points to the requested page
        // Mark the requested page (pointed by the current pointer) dirty
        listQueue->current->dirtyFlag=TRUE;
        return RC_OK;
    }
}
/*Unpin Page*/
RC unpinPage (BM_BufferPool *const bm, BM_PageHandle *const page)
{
    queue *listQueue = (queue*) bm->mgmtData;
    RC RC_Search = seekPage(bm,page,page->pageNum);
    //if something unexpected error happens  or page not found, then return rc
    if (RC_Search!=RC_OK)
    {
        return RC_NA;
    }
    // Set fix count
    listQueue->current->fixCount-=1;
    return RC_OK;
}
/*Force a single dirty page to disk*/
RC forcePage (BM_BufferPool *const bm, BM_PageHandle *const page)
{
    queue *listQueue=(queue*) bm->mgmtData;
    openPageFile(bm->pageFile, fHandle);
    //write it back to disk.
    listQueue->current->totalWriteSinglePage=1;
    //If page need to be replaced found then write it in disk.
    RC RC_Write=writeBlock(page->pageNum,fHandle,page->data);
    totalWritePage++;
    if(RC_Write!=RC_OK)
    {
        closePageFile(fHandle);
        RC_NA;
    }
    listQueue->current->totalWriteSinglePage=0;
    listQueue->current->dirtyFlag=FALSE;
    closePageFile(fHandle);
    return RC_OK;
}
/*Force all dirty pages to disk*/
RC forceFlushPool(BM_BufferPool *const bm)
{
    queue *listQueue=(queue*) bm->mgmtData;
    openPageFile(bm->pageFile, fHandle);
    for(listQueue->current=listQueue->head;listQueue->current!=listQueue->tail;
        listQueue->current=listQueue->current->nextFrame)
    {
        if((listQueue->current->fixCount==0||listQueue->current->totalReadSinglePage==0||
            listQueue->current->totalWriteSinglePage==0) && listQueue->current->dirtyFlag==TRUE)
        {
            //write it back to disk.
            listQueue->current->totalWriteSinglePage=1;
            //If page need to be replaced found then write it in disk.
            RC RC_Write=writeBlock(listQueue->current->pageFrameInfo->pageNum, fHandle,
                                   listQueue->current->pageFrameInfo->data);
            totalWritePage++;
            if(RC_Write!=RC_OK)
            {
                closePageFile(fHandle);
                RC_NA;
            }
            listQueue->current->totalWriteSinglePage=0;
            listQueue->current->dirtyFlag=FALSE;
        }
    }
    if(listQueue->current==listQueue->tail && (listQueue->current->fixCount==0||
                                               listQueue->current->totalReadSinglePage==0||
                                               listQueue->current->totalWriteSinglePage==0) &&
       listQueue->current->dirtyFlag==TRUE)
    {
        //write it back to disk.
        listQueue->current->totalWriteSinglePage=1;
        //If page need to be replaced found then write it in disk.
        RC RC_Write=writeBlock(listQueue->current->pageFrameInfo->pageNum, fHandle,
                               listQueue->current->pageFrameInfo->data);
        totalWritePage++;
        if(RC_Write!=RC_OK)
        {
            closePageFile(fHandle);
            RC_NA;
        }
        listQueue->current->totalWriteSinglePage=0;
        listQueue->current->dirtyFlag=FALSE;
    }
    closePageFile(fHandle);
    return RC_OK;
}
/*Shutdown buffer pool*/
RC shutdownBufferPool(BM_BufferPool *const bm)
{
    queue *listQueue=(queue*) bm->mgmtData;
    RC RC_Force=forceFlushPool(bm);
    if(RC_Force==RC_OK)
    {
        free(listQueue->current->pageFrameInfo->data);
        free(listQueue->current->pageFrameInfo);
        free(listQueue);
        free(fHandle);
        return RC_OK;
    }
    return RC_NA;
}
//return page numbers
PageNumber *getFrameContents (BM_BufferPool *const bm)
{
    PageNumber *framePageNums= (PageNumber*)malloc(sizeof(PageNumber)*bm->numPages);
    queue *listQueue=(queue*) bm->mgmtData;
    int i=0;
    int j=0;
    if(listQueue->queueSize==0)
    {
        framePageNums[i]=listQueue->head->pageFrameInfo->pageNum;
        i++;
    }
    else
    {
        for(listQueue->current=listQueue->head;listQueue->current!=listQueue->tail;
            listQueue->current=listQueue->current->nextFrame)
        {
            framePageNums[i]=listQueue->current->pageFrameInfo->pageNum;
            i++;
        }
        if(listQueue->current==listQueue->tail)
        {
            framePageNums[i]=listQueue->tail->pageFrameInfo->pageNum;
            i++;
        }

    }
    j=bm->numPages;
    if(i<j)
    {
        while(i<j)
        {
            framePageNums[i]=NO_PAGE;
            i++;
        }
    }
    return framePageNums;
}
/*returns an array of bools indicating each page is dirty or not.*/
bool *getDirtyFlags (BM_BufferPool *const bm)
{
    bool *dirtyFrames=(bool*)malloc(sizeof(bool)*bm->numPages);
    queue *listQueue=(queue*) bm->mgmtData;
    int i=0;
    int j=0;
    if(listQueue->queueSize==0)
    {
        dirtyFrames[i]=listQueue->head->dirtyFlag;
        i++;
    }
    else
    {
        for(listQueue->current=listQueue->head;listQueue->current!=listQueue->tail;
            listQueue->current=listQueue->current->nextFrame)
        {
            dirtyFrames[i]=listQueue->current->dirtyFlag;
            i++;
        }
        if(listQueue->current==listQueue->tail)
        {
            dirtyFrames[i]=listQueue->tail->dirtyFlag;
            i++;
        }
    }
    j=bm->numPages;
    if(i<j)
    {
        while(i<j)
        {
            dirtyFrames[i]=FALSE;
            i++;
        }
    }
    /*listQueue->current=listQueue->head;
     for(int i = 0; i < bm->numPages; i++)
     {
     dirtyFrames[i] = (listQueue->current->dirtyFlag == 1) ? true : false ;
     listQueue->current=listQueue->current->nextFrame;
     }*/
    return dirtyFrames;
}
/*return an array of fix count of each page frame.*/
int *getFixCounts (BM_BufferPool *const bm)
{
    int *frameFixCount=(int*)malloc(sizeof(int)*bm->numPages);
    queue *listQueue=(queue*) bm->mgmtData;
    int i=0;
    int j=0;
    if(listQueue->queueSize==0)
    {
        frameFixCount[i]=listQueue->head->fixCount;
        i++;
    }
    else
    {
        for(listQueue->current=listQueue->head;listQueue->current!=listQueue->tail;
            listQueue->current=listQueue->current->nextFrame)
        {
            frameFixCount[i]=listQueue->current->fixCount;
            i++;
        }
        if(listQueue->current==listQueue->tail)
        {
            frameFixCount[i]=listQueue->tail->fixCount;
            i++;
        }
    }
    
    j=bm->numPages;
    if(i<j)
    {
        while(i<j)
        {
            frameFixCount[i]=0;
            i++;
        }
    }
    return frameFixCount;
}
/*return the number of pages read since buffer pool is initialized.*/
int getNumReadIO (BM_BufferPool *const bm)
{
    return totalReadPage;
}
/*return the number of pages read since buffer pool is initialized.*/
int getNumWriteIO (BM_BufferPool *const bm)
{
    return totalWritePage;
}
