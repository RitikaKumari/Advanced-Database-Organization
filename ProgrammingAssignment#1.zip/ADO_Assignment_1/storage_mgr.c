#include<stdio.h>
#include<stdlib.h>
#include"storage_mgr.h"
#include"dberror.h"

FILE *fp;  //File pointer

/* manipulating page files */
extern void initStorageManager (void)
{

}

/* CreatePageFile method creates a new page file fileName. The initial file size is of one page. This method fills this single page with '\0' bytes.*/
extern RC createPageFile (char *fileName)
{
  char *memoryPointer;  //Memory pointer
  fp=fopen(fileName,"w");
  if(fp==NULL)
  {
     RC_message="File does not exists!";
     return RC_FILE_NOT_FOUND;
  }
  memoryPointer=(char*)calloc(PAGE_SIZE,sizeof(char));
  //writing from memory to file in binary mode.
  fwrite(memoryPointer,PAGE_SIZE,1,fp);
  RC_message="File created successfully!";
  return RC_OK;
}

/*Opens an existing page file. Should return RC_FILE_NOT_FOUND if the file does not exist. The second parameter is an existing file handle. If opening the file is successful, then the fields of this file handle should be initialized with the information about the opened file. For instance, you would have to read the total number of pages that are stored in the file from disk.*/
extern RC openPageFile (char *fileName, SM_FileHandle *fHandle)
{
  FILE *fp;
  int size;  
  if(!(fp=fopen(fileName,"r")))
  {
     RC_message="File does not exists!";     
     return RC_FILE_NOT_FOUND;
  }
  else
  {
     fp=fopen(fileName,"r");
     fHandle->fileName=fileName;
     //move pointer at the end of the file.
     fseek(fp,0,SEEK_END);
     size=ftell(fp);  //tells the current position of the pointer in the file.
     fHandle->totalNumPages=size/PAGE_SIZE;
     fHandle->curPagePos=0;  //Current page# starting with 0.
     fHandle->mgmtInfo=fp;
     RC_message="File opened successfully!";
     return RC_OK;
  }
}

/*Close an open page file.*/
extern RC closePageFile (SM_FileHandle *fHandle)
{
  if(fp==NULL)
  {
     fHandle=NULL;
     RC_message="File does not exists to close!";
     return RC_FILE_NOT_FOUND;
  }
  else
  {
     fHandle=NULL;
     fclose(fp);
     fp=NULL;
     RC_message="File closed successfully!";
     return RC_OK;
  }
}
/*Destroy (Delete) a page file.*/
extern RC destroyPageFile (char *fileName)
{
  //Destroy or Delete file after it is compiled and executed
  remove(fileName);
  RC_message="File deleted successfully!";
  return RC_OK;
}

/* reading blocks from disc */
/*The method reads the pageNumth block from a file and stores its content in the 
memory pointed to by the memPage page handle. If the file has less than pageNum pages, 
the method should return RC_READ_NON_EXISTING_PAGE.*/
extern RC readBlock (int pageNum, SM_FileHandle *fHandle, SM_PageHandle memPage)
{
  if(fHandle==NULL)
  {
     RC_message="No Data!";
     return RC_FILE_HANDLE_NOT_INIT;
  }
  else
  {
     //Total Pages greater than or equal to page number.
     //Page# starts with 0 in file.
     if(fHandle->totalNumPages>=(pageNum+1) && pageNum==0)
     {
        if(memPage!=NULL)
        {
           //Move the pointer position to the beginning of the file.
           fseek(fp,PAGE_SIZE,SEEK_SET);
           fread(memPage,1,PAGE_SIZE,fp);  //file is read and written data into memory.
           fHandle->curPagePos=pageNum;
           RC_message="File content read successfully!";
           return RC_OK;
        }
     }
     else if(fHandle->totalNumPages>=(pageNum+1) && pageNum>0)
     {
        if(memPage!=NULL)
        {
           //Move the pointer position to the end of the file.
           fseek(fp,(pageNum+1)*PAGE_SIZE,SEEK_SET);
           fread(memPage,1,PAGE_SIZE,fp);  //file is read and written data into memory.
           fHandle->curPagePos=pageNum;
           RC_message="File content read successfully!";
           return RC_OK;
        }
     }
     else
     { 
        RC_message="Pages not found in the file!";
        return RC_READ_NON_EXISTING_PAGE;   //Total Pages less than page number.
     }     
  }
}

/*Return the current page position in a file*/
extern int getBlockPos (SM_FileHandle *fHandle)
{
  if(fHandle==NULL)
  {
     RC_message="No Data!";
     return RC_FILE_HANDLE_NOT_INIT;
  }
  else
  {
     return (fHandle->curPagePos);
  }
}

/*Read the first page in a file.*/
extern RC readFirstBlock (SM_FileHandle *fHandle, SM_PageHandle memPage)
{
  if(fHandle==NULL)
  {
     RC_message="No Data!";
     return RC_FILE_HANDLE_NOT_INIT;
  }
  else
  {
     return readBlock (0,fHandle,memPage);    
  }
}

/*Read the previous page relative to the curPagePos of the file. The curPagePos should be moved to the page that was read.
If the user tries to read a block before the first page of after the last page of the file, the method should return RC_READ_NON_EXISTING_PAGE.*/
extern RC readPreviousBlock (SM_FileHandle *fHandle, SM_PageHandle memPage)
{
  if(fHandle==NULL)
  {
     RC_message="No Data!";
     return RC_FILE_HANDLE_NOT_INIT;
  }
  else if(fHandle!=NULL && getBlockPos(fHandle)==0)
  {
     RC_message="No previous page available to read!";
     return RC_READ_NON_EXISTING_PAGE;
  }
  else if(fHandle!=NULL && getBlockPos(fHandle)>0)
  {
     return readBlock ((getBlockPos(fHandle)-1),fHandle,memPage);
  }
  else
  {
     RC_message="Can't perform reading of prvious block!";
     return RC_FAILED_OPERATION;
  }
}

/*Read the current page relative to the curPagePos of the file. The curPagePos should be moved to the page that was read. 
If the user tries to read a block before the first page of after the last page of the file, the method should return RC_READ_NON_EXISTING_PAGE.*/
extern RC readCurrentBlock (SM_FileHandle *fHandle, SM_PageHandle memPage)
{
  if(fHandle==NULL)
  {
     RC_message="No Data!";
     return RC_FILE_HANDLE_NOT_INIT;
  }
  else if(fHandle!=NULL && getBlockPos(fHandle)>=0)
  {
     return readBlock (getBlockPos(fHandle),fHandle,memPage);
  }
  else
  {
     RC_message="No page to read!";
     return RC_READ_NON_EXISTING_PAGE;
  }
}

/*Read the current, previous, or next page relative to the curPagePos of the file. The curPagePos should be moved to the page that was read.
If the user tries to read a block before the first page of after the last page of the file, the method should return RC_READ_NON_EXISTING_PAGE.*/
extern RC readNextBlock (SM_FileHandle *fHandle, SM_PageHandle memPage)
{
  if(fHandle==NULL)
  {
     RC_message="No Data!";
     return RC_FILE_HANDLE_NOT_INIT;
  }
  else if(fHandle!=NULL && fHandle->totalNumPages<=(getBlockPos(fHandle)+1))
  {
     RC_message="No page to read!";
     return RC_READ_NON_EXISTING_PAGE;
  }
  else
  {
     return readBlock (getBlockPos(fHandle)+1,fHandle,memPage);
  }
}

/*Read the last page in a file*/
extern RC readLastBlock (SM_FileHandle *fHandle, SM_PageHandle memPage)
{
  if(fHandle==NULL)
  {
     RC_message="No Data!";
     return RC_FILE_HANDLE_NOT_INIT;
  }
  else
  {
     return readBlock (fHandle->totalNumPages-1,fHandle,memPage);    
  }
}

/*Write a page to disk.*/
extern RC writeBlock (int pageNum, SM_FileHandle *fHandle, SM_PageHandle memPage)
{
  if(fHandle==NULL)
  {
     RC_message="No Data!";
     return RC_FILE_HANDLE_NOT_INIT;
  }
  else
  {
     //Total Pages greater than or equal to page number.
     //Page# starts with 0 in file.
     if(fHandle->totalNumPages>pageNum && pageNum>=0)
     {
        if(memPage!=NULL)
        {
           //Move the pointer position to the beginning of the file.
           fseek(fp,(pageNum+1)*PAGE_SIZE,SEEK_SET);
           fwrite(memPage,1,PAGE_SIZE,fp);
           fHandle->curPagePos=pageNum;
           RC_message="File written successfully!";
           return RC_OK;
        }
     }
     else
     {
        RC_message="Pages not found in the file!";
        return RC_WRITE_FAILED;   //Total Pages less than page number then writing fails.
     }     
  }
}

/*Write a page to disk using current position*/
extern RC writeCurrentBlock (SM_FileHandle *fHandle, SM_PageHandle memPage)
{
   if(fHandle==NULL)  
   {
      RC_message="No Data!";
      return RC_FILE_HANDLE_NOT_INIT;
   }
   else
   {
      return writeBlock (getBlockPos(fHandle),fHandle,memPage);
   }
}

/*Increase the number of pages in the file by one. The new last page should be filled with zero bytes.*/
extern RC appendEmptyBlock (SM_FileHandle *fHandle)
{
  FILE *fp;
  char *memoryPointer;
  if(fHandle==NULL)
  {
     RC_message="No Data!";
     return RC_FILE_HANDLE_NOT_INIT;
  }
  else
  {
    fp=fopen(fHandle->fileName,"a");
    fHandle->totalNumPages=fHandle->totalNumPages+1;
    fseek(fp,(fHandle->totalNumPages)*PAGE_SIZE,SEEK_END);
    memoryPointer=(char*)calloc(PAGE_SIZE,sizeof(char));
    //writing from memory to file in binary mode.
    fwrite(memoryPointer,PAGE_SIZE,1,fp);
    fHandle->curPagePos=fHandle->totalNumPages-1;
    RC_message="An empty block or page is succedsfully added in the file!";
    return RC_OK;
  }
}

/*If the file has less than numberOfPages pages then increase the size to numberOfPages.*/
extern RC ensureCapacity (int numberOfPages, SM_FileHandle *fHandle)
{
  int x;
  if(fHandle==NULL)
  {
     RC_message="No Data!";
     return RC_FILE_HANDLE_NOT_INIT;
  }
  else if (numberOfPages<=fHandle->totalNumPages)
  {
     return RC_OK;
  }
  else
  {
     x=numberOfPages-fHandle->totalNumPages;
     for(int y=0;y<x;y++)
     {
        appendEmptyBlock(fHandle);
     }
     RC_message="File size has been increased successfully!";
     return RC_OK;
  }
}

