
Assignment 1 - Storage Manager
Submitted by Group No. 7 (vkamboj@hawk.iit.edu, rkumari@hawk.iit.edu , nchoudhary1@hawk.iit.edu , kpatel119@hawk.iit.edu)

***********************************************************
The assignment consists of three C files and three header files , a Makefile and a README: 
1. storage_mgr.c
2. storage_mgr.h
3. test_assign1.c
4. test_helper.h
5. dberror.c
6. dberror.h
7. Makefile
8. README

---------------------------------Makefile---------------------------

All the files are checked in the Bitbucket repository: (https://vinitkr123@bitbucket.org/gatesice/iit-cs525-assignment.git)

To run the files, you can execute any one of the below commands:
1. make 
2. make all

The above commands create an output file "test_assign1_1" and "test_assign1_2". This can be then executed using "./test_assign1_1" and "./test_assign1_2"

To clean the output files created use the command:"make clean"

--------------------------------storage_mgr.c---------------------------------
The declaration of interface storage_mgr.h is defined in storage_mgr.c. The implementation of each function in storage_mgr.c is described as follows:

void initStorageManager (void): 
1. We declares all the global variables used in our project to this block
2. But,for now there is not need to initialize any variable in "init" block

RC createPageFile (char *fileName): 
1. A new file is created in write mode.
2. Empty block is written to the file.

RC openPageFile (char *fileName, SM_FileHandle *fHandle):
1. Open the file in read+write mode
2. Stores the totalNumPages, curPagePos, fileName
3. Store the POSIX file pointer in mgmtInfo

RC closePageFile (SM_FileHandle *fHandle):
1. Close the file using fclose()
2. De-initialize the file handler

RC destroyPageFile (char *fileName):
1. Delete the file from the directory handled by file handler.

RC readBlock (int pageNum, SM_FileHandle *fHandle, SM_PageHandle memPage):
1. Checks if the page exists using the totalNumPages
2. In case the page exists, seek the file pointer until that page using built-in function "fseek"
3. Read the file into PageHandler from the seeked location for the next 4096 bytes using built-in function "fread"
4. In case the page does not exists return "NON_EXISTING_PAGE" error

int getBlockPos (SM_FileHandle *fHandle):
1. returns the current block position using curPagePos variable of the file handler

RC readFirstBlock (SM_FileHandle *fHandle, SM_PageHandle memPage):
function calls the readBlock function with pageNum=0

RC readPreviousBlock (SM_FileHandle *fHandle, SM_PageHandle memPage):
function calls the readBlock function with pageNum=curPagePos-1

RC readCurrentBlock (SM_FileHandle *fHandle, SM_PageHandle memPage):
Calls the readBlock function with pageNum=curPagePos

RC readNextBlock (SM_FileHandle *fHandle, SM_PageHandle memPage):
Calls the readBlock function with pageNum=curPagePos+1

RC readLastBlock (SM_FileHandle *fHandle, SM_PageHandle memPage):
Calls the readBlock function with pageNum=totalNumPages-1

RC writeBlock (int pageNum, SM_FileHandle *fHandle, SM_PageHandle memPage):
1. Checks if the page number is greater / equal to 0
2. In case the above condition is true, seek the file pointer until that page using built-in function "fseek"
3. In case the page to be written in greater than totalNumPages, increase the pages of the file as totalNumPages=pageNum+1
4. Write the data from the PageHandler to the seeked location for the next 4096 bytes using built-in function "fwite"
5. In case the page does not exists return "INVALID_PAGE_NUMBER" error

RC writeCurrentBlock (SM_FileHandle *fHandle, SM_PageHandle memPage):
Calls the writeBlock function with pageNum=curPagePos

RC appendEmptyBlock (SM_FileHandle *fHandle):
Calls the writeBlock fucntion with pageNum=totalNumPages and memPage=emptyblock

RC ensureCapacity (int numberOfPages, SM_FileHandle *fHandle):
Calls the writeBlock function with pageNum=numberOfPages-1 and memPage=emptyblock


---------test_assign1_2----------------


In addition to the test cases where have we have implemented other remaining test cases in additional "test_assign1_2" file 
Each of the test cases process the file "test_pagefile.bin"
