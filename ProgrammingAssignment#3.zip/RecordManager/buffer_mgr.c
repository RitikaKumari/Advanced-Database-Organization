#include "buffer_mgr.h"
#include <stdio.h>
#include <stdlib.h>
#include "storage_mgr.h"
#include "dberror.h"
#include "dt.h"

/*--------------------Data Structure & Variable declaration--------------------*/
//Structure for a page frame.
typedef struct frame{
    //Page Frame number.
    int frameNumber;
    //Fix count of page frame.
    int fixCount;
    //Counter for LRU.
    int count;
    //Counter for LFU.
    int lfuCount;
    //Counter for CLOCK
    int clockBit;
    //Pointer to access current's previous page frame in the buffer pool of type "frame" data structure.
    struct frame *previousFrame;
    //Pointer to access current's next page frame in the buffer pool of type "frame" data structure.
    struct frame *nextFrame;
    //Pointer of Buffer Pool Page Handler.
    struct BM_PageHandle *pageFrameInfo;
    //Dirty Flag
    bool dirtyBit;
} frame;

//Total number of pages read or write since buffer pool is initialized.
int totalReadPage, totalWritePage;

//Structure for a queue
typedef struct queue{
    //Queue size
    int queueSize;
    //Pointer of head, current and tail
    struct frame *head, *current, *tail;
}queue;

//File hadnler declaration
SM_FileHandle *fHandle;

/*-------------------------------------------------------------------------------*/

/*------------------------------Initialize Buffer Pool --------------------------
 * Function Name: initBufferPool
 *
 * Description:
 *        Initializing a buffer pool i.e. initializing all the pointers and variables.
 *
 * Parameters:
 *        BM_BufferPool *const bm: Buffer Pool Handler
 *        const char *const pageFileName: Page File (Disk FIle) name pointer,
 *        const int numPages: Number of pages a buffer pool should have,
 *        ReplacementStrategy strategy: Replacement Strategy used for replacing the pages in the buffer pool
 *        void *stratData: Not Applicable
 
 * Return: RC code
 -------------------------------------------------------------------------------*/
RC initBufferPool(BM_BufferPool *const bm, const char *const pageFileName,
                  const int numPages, ReplacementStrategy strategy,
                  void *stratData)
{
    char * pf=(char*)pageFileName;
    //Check whether buffer pool is addressing to memory or not.
    if(bm==NULL)
    {
        RC_message="Buffer Pool memory is not allocated!";
        return RC_BUFFER_POOL_FAILED;
    }
    //Check whether page file pointer is available is addressing to particular file or not.
    else if(pf==NULL)
    {
        RC_message="File not found!";
        return RC_FILE_NOT_FOUND;
    }
    //Check for number of pages requested by the buffer manager client to be loaded into the buffer pool.
    else if(numPages==0 || numPages<0)
    {
        RC_message="No pages or incorrect pages!";
        return RC_NO_PAGES;
    }
    else
    {
        bm->pageFile=pf;
        bm->numPages=numPages;
        bm->strategy=strategy;
        totalReadPage=0;
        totalWritePage=0;
        frame *f[bm->numPages];
        int i=0;
        while (i< bm->numPages)
        {
            f[i] = (frame*) malloc(sizeof(frame));
            f[i]->pageFrameInfo = MAKE_PAGE_HANDLE();
            f[i]->pageFrameInfo->pageNum=NO_PAGE;
            f[i]->pageFrameInfo->data=(char*)malloc(sizeof(char)*PAGE_SIZE);
            f[i]->frameNumber=i;
            f[i]->fixCount=0;
            f[i]->dirtyBit=FALSE;
            f[i]->count=0;
            f[i]->lfuCount=0;
            f[i]->clockBit=0;
            if(i==0)
            {
                f[i]->nextFrame=NULL;
                f[i]->previousFrame=NULL;
            }
            if(i>0)
            {
                f[i]->previousFrame=f[i-1];
                f[i-1]->nextFrame=f[i];
                f[i]->nextFrame=NULL;
            }
            
            i++;
        }
        //Queue initialization.
        queue *listQueue= (queue*) malloc (sizeof(queue));
        bm->mgmtData=listQueue;
        //Initially tail and current points to the head.
        listQueue->head=listQueue->tail=listQueue->current=f[0];
        //Queue size would be "0" initially.
        listQueue->queueSize=0;
        //File Handler initialization.
        fHandle=(SM_FileHandle*) malloc(sizeof(SM_FileHandle));
        RC_message="Buffer Pool initialized successfully!";
        //Return "RC_OK" on success.
        return RC_OK;
    }
}

/*----------------------------------Seek Page------------------------------------------
 * Function Name: seekPage
 *
 * Description:
 *        Search the requested page in the Buffer Pool,
 *        if found, load the requested page into the buffer pool page handler i.e. BM_pageHandle and return "RC_OK"
 *        else, return error code i.e. "RC_NO_PAGES" or "RC_NA".
 *
 * Parameters:
 *        BM_BufferPool * const bm: Buffer Pool Handler
 *        BM_PageHandle * const page: Buffer Pool Page Handler
 *        PageNumber pageNum: Requested page number by the client
 *
 * Return:
 *        RC: return code
 -------------------------------------------------------------------------------------*/
extern RC seekPage(BM_BufferPool *const bm, BM_PageHandle *const page, const PageNumber pageNum)
{
    queue *listQueue=(queue*) bm->mgmtData;
    //Check whether queue size is equal to 0. If queue size is 0 than return "RC_NO_PAGES".
    if(listQueue->queueSize==0)
    {
        return RC_NO_PAGES;
    }
    //Check whether queue size greater than 0.
    if(listQueue->queueSize>0)
    {
        //Search for the requested page number.
        /*If requested page is found in the queue or buffer pool than return "RC_OK" and load page data in the buffer pool page handler. If requested page number is not found in the queue(except tail) then, exit from the for loop.*/
        for(listQueue->current=listQueue->head;listQueue->current!=listQueue->tail;
            listQueue->current=listQueue->current->nextFrame)
        {
            //Check whether current's page number is equal to the requested page number or not.
            if(listQueue->current->pageFrameInfo->pageNum==pageNum)
            {
                //load current's page number and page content to the buffer pool page handler.
                page->pageNum=pageNum;
                page->data=listQueue->current->pageFrameInfo->data;
                return RC_OK;
            }
        }
        /*Check whether tail having requested page number or not. If requested page is found in the tail of the queue or buffer pool than return "RC_OK" and load page data in the buffer pool page handler.*/
        if(listQueue->current==listQueue->tail && listQueue->current->pageFrameInfo->pageNum==pageNum)
        {
            page->pageNum=pageNum;
            page->data=listQueue->current->pageFrameInfo->data;
            return RC_OK;
        }
    }
    /*If requested page is not found in the queue or buffer pool than return "RC_NA".*/
    return RC_NA;
}

/*----------------------------------Increase Capacity------------------------------
 *Function Name: increaseCapacity
 *
 * Description:
 *        Used to increase the disk file capacity if there is not enough space in the disk file.
 *
 * Parameters:
 *        BM_BufferPool * const bm: Buffer Pool Handler
 *        BM_PageHandle * const page: Buffer Pool Page Handler
 *        PageNumber pageNum: Requested page number by the client
 *
 * Return:
 *        RC: return code
 ----------------------------------------------------------------------------------*/
extern RC increaseCapacity(BM_BufferPool *const bm, BM_PageHandle *const page, const PageNumber pageNum)
{
    //Call ensureCapacity method of "storage_mgr.c" file to increase the capacity of the disk file.
    RC RC_Ensure=ensureCapacity(pageNum+1, fHandle);
    //If "ensureCapacity" function fails then, return "RC_NA".
    if(RC_Ensure!=RC_OK)
    {
        return RC_NA;
    }
    //If disk file size is increased successfully then, return "RC_OK".
    return RC_OK;
}

/*-----------------------------------FIFO Strategy---------------------------------
 * Function Name: FIFO_Strategy
 *
 * Description:
 *        FIFO i.e. First In First Out page replacement strategy.
 *        In order to implement FIFO, queue data structure is used.
 *
 * Parameters:
 *        BM_BufferPool * const bm: Buffer Pool Handler
 *        BM_PageHandle * const page: Buffer Pool Page Handler
 *        PageNumber pageNum: Requested page number by the client
 *
 * Return:
 *        RC: return code
 ---------------------------------------------------------------------------------*/
RC FIFO_Strategy(BM_BufferPool *const bm, BM_PageHandle *const page,
                 const PageNumber pageNum)
{
    //Check whether buffer pool is addressing to memory or not.
    if(bm==NULL)
    {
        return RC_BUFFER_POOL_FAILED;
    }
    //Check whether buffer pool page handler is addressing to memory or not.
    if(page==NULL)
    {
        return RC_BUFFER_POOL_HANDLE_NOT_INIT;
    }
    //Check whether request page number by the client has a valid number or not.
    if(pageNum<0)
    {
        return RC_NO_PAGES;
    }
    queue *listQueue=(queue*)bm->mgmtData;
    
    //Search for the maximum LRU count for the LRU page replacement strategy.
    //Declaring a maxCount variable and assigning count value of head's page initially.
    int maxCount=listQueue->head->count;
    //For loop for searching a maximum LRU count starting from head till the node before tail.
    for(listQueue->current=listQueue->head;listQueue->current!=listQueue->tail;
        listQueue->current=listQueue->current->nextFrame)
    {
        /*If current's next's page's count is maximum compared to the count of current's page then, assign the current's next's page's count to the maxCount variable.*/
        if(maxCount<listQueue->current->nextFrame->count)
        {
            maxCount=listQueue->current->nextFrame->count;
        }
    }
    /*If tail's page's count is maximum compared to the tail's previous page's count then, assign the tail's page's count to the maxCount variable.*/
    if(listQueue->current==listQueue->tail && maxCount<listQueue->tail->count)
    {
        maxCount=listQueue->tail->count;
    }
    
    /*Search wether requested page number by the client is already present in the queue or in the buffer pool or not. For this call seekPage function.*/
    RC RC_Seek=seekPage(bm, page, pageNum);
    
    /*If requested page number is found in the queue then update fix count, LRU counter, LFU counter, clock bit and return "RC_SEEK_SUCCESS".*/
    if(RC_Seek==RC_OK)
    {
        //Increase the fix count of the current's page by 1.
        listQueue->current->fixCount+=1;
        //Update LRU counter by maximum LRU count + 1.
        listQueue->current->count=maxCount+1;
        //Update LFU counter by 1.
        listQueue->current->lfuCount=(listQueue->current->lfuCount)+1;
        /*Check for the clock bit. If clock bit of current's page is "0" then update it to "1". If already clock bit of current's page is "1" then do not update the clock bit.*/
        if(listQueue->current->clockBit==0)
        {
            listQueue->current->clockBit=1;
        }
        return RC_SEEK_SUCCESS;
    }
    //If requested page number is not found in the queue.
    if(RC_Seek==RC_NO_PAGES || RC_Seek==RC_NA)
    {
        /*First check whether requested page number is available in the disk file or not by calling "openPageFile" function of "storage_mgr.c" file.*/
        RC RC_Open=openPageFile(bm->pageFile, fHandle);
        //If openPageFile function fails then, close the file and return "RC_NA".
        if(RC_Open!=RC_OK)
        {
            closePageFile(fHandle);
            return RC_NA;
        }
        //If "openPageFile" function of "storage_mgr.c" returns "RC_OK".
        if(fHandle->totalNumPages<pageNum+1)
        {
            /*Check whether disk file is having capacity such that it can accommodate at least requested page number in the disk file.
             If Disk File has page number as requested page number by the client then do not increase the capacity and if disk file does not have page number as requested page number by the client then increase the disk capacity to accommodate the requested page number.*/
            RC RC_Increase=increaseCapacity(bm,page,pageNum);
            //If increase capacity fails then close the opened file and return "RC_NA".
            if(RC_Increase!=RC_OK)
            {
                closePageFile(fHandle);
                return RC_NA;
            }
        }
        //If queue is empty then read the requested page from the disk file to queue's head. Also it loads data from the disk file to the head's page.
        if(listQueue->queueSize==0)
        {
            /*Increase the fix count of current's page as client has requested to read the page number from disk file to buffer pool.*/
            listQueue->current->fixCount++;
            /*Read the data from the disk file for the requested page number by the client, by calling "readBlock" function of "storage_mgr.c" file and load the data into the buffer pool's current's page's buffer pool page handler in order to load data into the current's page in the buffer pool.*/
            RC RC_Read=readBlock(pageNum, fHandle, listQueue->current->pageFrameInfo->data);
            //Increase the total read page counter by 1.
            totalReadPage++;
            //Initially when queue size is "0" then, total write count should be "0".
            totalWritePage=0;
            //If "readBlock" method fails then, close the opened file and return "RC_NA".
            if(RC_Read!=RC_OK)
            {
                closePageFile(fHandle);
                return RC_NA;
            }
            //If "readBlock" method returns "RC_OK" i.e. read is performed successfully.
            else
            {
                //Close the opened disk file.
                closePageFile(fHandle);
                //Update the dirty flag to "FALSE".
                listQueue->current->dirtyBit=FALSE;
                //update current's page's page number by the requested page number by the client.
                listQueue->current->pageFrameInfo->pageNum=pageNum;
                //Set LRU counter equal to "1".
                listQueue->current->count=1;
                //Set LFU counter to "1".
                listQueue->current->lfuCount=1;
                //Set Clock bit to "1".
                listQueue->current->clockBit=1;
                //Increase the queue size by 1.
                listQueue->queueSize=listQueue->queueSize+1;
                //Load the buffer pool page handler page number by the current's page's page number.
                page->pageNum=pageNum;
                //Load the buffer pool page handler data by the current's page's data.
                page->data=listQueue->current->pageFrameInfo->data;
                //Return "RC_OK" for success.
                return RC_OK;
            }
        }
        //If queue size is not "0" and also queue size is less than the number of pages a buffer pool can accommodate.
        if(listQueue->queueSize!=0 && listQueue->queueSize<bm->numPages)
        {
            //Search for the maximum LRU count for the LRU page replacement strategy.
            //Declaring a maxCount variable and assigning count value of head's page initially
            int maxCount=listQueue->head->count;
            //For loop for searching a maximum LRU count starting from head till the node before tail.
            for(listQueue->current=listQueue->head;listQueue->current!=listQueue->tail;
                listQueue->current=listQueue->current->nextFrame)
            {
                /*If current's next's page's count is maximum compared to the count of current's page then, assign the current's next's page's count to the maxCount variable.*/
                if(maxCount<listQueue->current->nextFrame->count)
                {
                    maxCount=listQueue->current->nextFrame->count;
                }
            }
            /*If tail's page's count is maximum compared to the maximum count of tail's previous page's count then, assign the tail's page's count to the maxCount variable.*/
            if(listQueue->current==listQueue->tail && maxCount<listQueue->tail->count)
            {
                maxCount=listQueue->tail->count;
            }
            //Increase the fix count of current's next frame by 1.
            listQueue->tail->nextFrame->fixCount++;
            /*Read the data from the disk file for the requested page number by the client, by calling "readBlock" function of "storage_mgr.c" file and load the data into the buffer pool's current's next's page's buffer pool page handler in order to load data into the current's page in the buffer pool.*/
            RC RC_Read=readBlock(pageNum, fHandle, listQueue->tail->nextFrame->pageFrameInfo->data);
            //Increase the total read count by "1".
            totalReadPage++;
            //total write count "0".
            totalWritePage=0;
            //If "readBlock" method fails then, close the opened file and return "RC_NA".
            if(RC_Read!=RC_OK)
            {
                closePageFile(fHandle);
                return RC_NA;
            }
            //If "readBlock" method returns "RC_OK" i.e. read is performed successfully.
            else
            {
                //Close the opened disk file.
                closePageFile(fHandle);
                //Update the current's next's page's dirty flag to "FALSE".
                listQueue->tail->nextFrame->dirtyBit=FALSE;
                //Update current's next's page's page number by the requested page number by the client.
                listQueue->tail->nextFrame->pageFrameInfo->pageNum=pageNum;
                //Update tail.
                listQueue->tail=listQueue->tail->nextFrame;
                //Update current as tail.
                listQueue->current=listQueue->tail;
                //Set current's page's LRU counter equal to maxCount + 1.
                listQueue->current->count=maxCount+1;
                //Set current page's LFU counter to "1".
                listQueue->current->lfuCount=1;
                //Set current page's Clock bit to "1".
                listQueue->current->clockBit=1;
                //Increase the queue size by 1.
                listQueue->queueSize=listQueue->queueSize+1;
                //Load the buffer pool page handler page number by the current's page's page number.
                page->pageNum=pageNum;
                //Load the buffer pool page handler data by the current's page's data.
                page->data=listQueue->current->pageFrameInfo->data;
                //Return "RC_OK" for success.
                return RC_OK;
            }
        }
        /*If queue is full i.e. no space in queue to read disk file page then replace the first entered page having fix count=0 by the page read from the disk file.*/
        if(listQueue->queueSize!=0 && listQueue->queueSize>=bm->numPages)
        {
            //Search for the maximum LRU count for the LRU page replacement strategy.
            //Declaring a maxCount variable and assigning count value of head's page initially.
            int maxCount=listQueue->head->count;
            //For loop for searching a maximum LRU count starting from head till the node before tail.
            for(listQueue->current=listQueue->head;listQueue->current!=listQueue->tail;
                listQueue->current=listQueue->current->nextFrame)
            {
                /*If current's next's page's count is maximum compared to the count of current's page then, assign the current's next's page's count to the maxCount variable.*/
                if(maxCount<listQueue->current->nextFrame->count)
                {
                    maxCount=listQueue->current->nextFrame->count;
                }
            }
            /*If tail's page's count is maximum compared to the maximum count of tail's previous page's count then, assign the tail's page's count to the maxCount variable.*/
            if(listQueue->current==listQueue->tail && maxCount<listQueue->tail->count)
            {
                maxCount=listQueue->tail->count;
            }
            //Assign the head's page's page number to the variable named "smallest".
            int smallest=listQueue->head->pageFrameInfo->pageNum;
            //For loop for searching smallest page number having fix count equal to "0" starting from head till the node before tail.
            for(listQueue->current=listQueue->head;listQueue->current!=listQueue->tail;
                listQueue->current=listQueue->current->nextFrame)
            {
                /*If current's next's page's page number is small compared to the page number of current's page and current's next's page's fix count is equal to "0" then, assign the current's next's page's page number to the "smallest" variable.
                 If, if condition is not satisfied that means current is tail and tail's page's page number is the smallest and also it's fix count is equal to "0".*/
                if(smallest>listQueue->current->nextFrame->pageFrameInfo->pageNum &&
                   listQueue->current->nextFrame->fixCount==0)
                {
                    smallest=listQueue->current->nextFrame->pageFrameInfo->pageNum;
                }
            }
            /* Write the smallest numbered page number's page content back to the disk file (this smallest should have fix count = 0) and read the requested page number from the disk file.*/
            for(listQueue->current=listQueue->head;listQueue->current!=listQueue->tail;
                listQueue->current=listQueue->current->nextFrame)
            {
                if(listQueue->current->pageFrameInfo->pageNum==smallest)
                {
                    /* Writing is performed when actually page in queue is modified and then write modified page on disk or else directly load requested page from the disk file into queue's current.*/
                    RC RC_Write=writeBlock(listQueue->current->pageFrameInfo->pageNum, fHandle,
                                           listQueue->current->pageFrameInfo->data);
                    if(listQueue->current->dirtyBit==TRUE)
                    {
                        //Increment the total write counter by "1" as page is written in the disk file.
                        totalWritePage++;
                    }
                    //If write fails then close the opened file and return "RC_NA".
                    if(RC_Write!=RC_OK)
                    {
                        closePageFile(fHandle);
                        RC_NA;
                    }
                    //Read the requested page from the disk file and load the data to the queue's current page.
                    RC RC_Read=readBlock(pageNum, fHandle, listQueue->current->pageFrameInfo->data);
                    /* Increment the current's page's fix count by "1" as page(requested page number) is read from the disk.*/
                    listQueue->current->fixCount++;
                    //Increment the total read counter as page is read from the disk file and loaded on the buffer pool.
                    totalReadPage++;
                    //If reading fails then close the disk file and return "RC_NA".
                    if(RC_Read!=RC_OK)
                    {
                        closePageFile(fHandle);
                        return RC_NA;
                    }
                    //After successful reading, close the disk file.
                    closePageFile(fHandle);
                    //Update the current's page's dirty flag to "FALSE".
                    listQueue->current->dirtyBit=FALSE;
                    //Set current's page's LRU counter equal to maxCount + 1.
                    listQueue->current->count=maxCount+1;
                    //Update current's page's page number by the requested page number by the client.
                    listQueue->current->pageFrameInfo->pageNum=pageNum;
                    //Load the buffer pool page handler page number by the current's page's page number.
                    page->pageNum=pageNum;
                    //Load the buffer pool page handler data by the current's page's data.
                    page->data=listQueue->current->pageFrameInfo->data;
                    //Return "RC_OK" on success.
                    return RC_OK;
                }
            }
            /* If current is tail and current's page has the smallest page number then Write the smallest page number's page content back to disk file (this smallest page number page should have fix count = 0) and read the requested page number from the disk file.*/
            if(listQueue->current==listQueue->tail && listQueue->current->pageFrameInfo->pageNum==smallest)
            {
                /* Writing is performed when actually page in queue is modified and then write modified page on disk or else directly load requested page from the disk file into queue's current.*/
                RC RC_Write=writeBlock(listQueue->current->pageFrameInfo->pageNum, fHandle,
                                       listQueue->current->pageFrameInfo->data);
                //If replaced page's dirty flag was "TRUE".
                if(listQueue->current->dirtyBit==TRUE)
                {
                    //Increment the total write counter by "1" as page is written in the disk file.
                    totalWritePage++;
                }
                //If write fails then close the opened file and return "RC_NA".
                if(RC_Write!=RC_OK)
                {
                    closePageFile(fHandle);
                    RC_NA;
                }
                //Read the requested page from the disk file and load the data to the queue's current page.
                RC RC_Read=readBlock(pageNum, fHandle, listQueue->current->pageFrameInfo->data);
                /* Increment the current's page's fix count by "1" as page(requested page number) is read from the disk.*/
                listQueue->current->fixCount++;
                //Increment the total read counter as page is read from the disk file and loaded on the buffer pool.
                totalReadPage++;
                //If reading fails then close the disk file and return "RC_NA".
                if(RC_Read!=RC_OK)
                {
                    closePageFile(fHandle);
                    return RC_NA;
                }
                //After successful reading, close the disk file.
                closePageFile(fHandle);
                //Update the current's page's dirty flag to "FALSE".
                listQueue->current->dirtyBit=FALSE;
                //Set current's page's LRU counter equal to maxCount + 1.
                listQueue->current->count=maxCount+1;
                //Update current's page's page number by the requested page number by the client.
                listQueue->current->pageFrameInfo->pageNum=pageNum;
                //Load the buffer pool page handler page number by the current's page's page number.
                page->pageNum=pageNum;
                //Load the buffer pool page handler data by the current's page's data.
                page->data=listQueue->current->pageFrameInfo->data;
                //Return "RC_OK" on success.
                return RC_OK;
            }
            return RC_NA;//No case is suucessful
        }
    }
    return RC_NA; //No case is successful.
}

/*--------------------------------------LRU Strategy---------------------------------
 * Function Name: LRU_Strategy
 *
 * Description:
 *        LRU page replacement strategy
 *
 * Parameters:
 *        BM_BufferPool * const bm: Buffer Pool Handler
 *        BM_PageHandle * const page: Buffer Pool Page Handler
 *        PageNumber pageNum: Requested page number by the client
 *
 * Return:
 *        RC: return code
 -------------------------------------------------------------------------------- */
RC LRU_Strategy(BM_BufferPool *const bm, BM_PageHandle *const page,
                const PageNumber pageNum)
{
    queue *listQueue = (queue*) bm->mgmtData;
    //If queue size is "0" or queue is empty.
    if(listQueue->queueSize==0)
    {
        //Call "FIFO_Strategy" function to add the requested page by the client.
        FIFO_Strategy(bm, page, pageNum);
        //Return "RC_OK" for success.
        return RC_OK;
    }
    //If queue size is not "0" and queue size is less than the number of pages buffer pool can accommodate.
    if(listQueue->queueSize!=0 && listQueue->queueSize<bm->numPages)
    {
        //Call "FIFO_Strategy" function to add the requested page by the client.
        FIFO_Strategy(bm, page, pageNum);
        //Return "RC_OK" for success.
        return RC_OK;
    }
    //If queue size is not "0" and queue size is more than or equal to the number of pages buffer pool can accommodate.
    if(listQueue->queueSize!=0 && listQueue->queueSize>=bm->numPages)
    {
        //Search for the maximum LRU count for the LRU page replacement strategy.
        //Declaring a maxCount variable and assigning count value of head's page initially.
        int maxCount=listQueue->head->count;
        //For loop for searching a maximum LRU count starting from head till the node before tail.
        for(listQueue->current=listQueue->head;listQueue->current!=listQueue->tail;
            listQueue->current=listQueue->current->nextFrame)
        {
            /*If current's next's page's count is maximum compared to the count of current's page then, assign the current's next's page's count to the maxCount variable.*/
            if(maxCount<listQueue->current->nextFrame->count)
            {
                maxCount=listQueue->current->nextFrame->count;
            }
        }
        /*If tail's page's count is maximum compared to the tail's previous page's count then, assign the tail's page's count to the maxCount variable.*/
        if(listQueue->current==listQueue->tail && maxCount<listQueue->tail->count)
        {
            maxCount=listQueue->tail->count;
        }
        //Search for the minimum LRU count for the LRU page replacement strategy.
        //Declaring a minCount variable and assigning LRU count value of head's page initially.
        int minCount=listQueue->head->count;
        //For loop for searching a minimum LRU count starting from head till the node before tail.
        for(listQueue->current=listQueue->head;listQueue->current!=listQueue->tail;
            listQueue->current=listQueue->current->nextFrame)
        {
            /*If current's next's page's LRU count is minimum compared to the LRU count of current's page then, assign the current's next's page's LRU count to the minCount variable.*/
            if(minCount>listQueue->current->nextFrame->count)
            {
                minCount=listQueue->current->nextFrame->count;
            }
        }
        /*If tail's page's LRU count is minimum compared to the tail's previous page's LRU count then, assign the tail's page's LRU count to the minCount variable.*/
        if(listQueue->current==listQueue->tail && minCount>listQueue->tail->count)
        {
            minCount=listQueue->tail->count;
        }
        /* Search wether requested page number is already present in the queue or in the buffer pool or not by calling "seekPage" function.*/
        RC RC_Search=seekPage(bm, page, pageNum);
        /* If search is successful then increase the current's page's LRU counter by maxCount+1 and also increase the current's page's fix count by "1".*/
        if(RC_Search==RC_OK)
        {
            listQueue->current->count=maxCount+1;
            listQueue->current->fixCount+=1;
        }
        /* If search is unsuccessful then, page having smallest LRU count is written back to the disk file and read the requested page number from the disk file to that page whose content has been written back to the disk file.*/
        if(RC_Search==RC_NA)
        {
            /*For loop for searching page having smallest or least LRU count. Searching is performed from head till node before tail.*/
            for(listQueue->current=listQueue->head;listQueue->current!=listQueue->tail;
                listQueue->current=listQueue->current->nextFrame)
            {
                //If condition to check current's page's LRU count is the smallest or not.
                if(listQueue->current->count==minCount)
                {
                    /* Writing is performed when actually page in queue is modified and then write modified page on disk or else directly load requested page from the disk file into queue's current.*/
                    RC RC_Write=writeBlock(listQueue->current->pageFrameInfo->pageNum, fHandle,
                                           listQueue->current->pageFrameInfo->data);
                    //If replaced page's dirty flag was "TRUE".
                    if(listQueue->current->dirtyBit==TRUE)
                    {
                        //Increment the total write counter by "1" as page is written in the disk file.
                        totalWritePage++;
                    }
                    //If write fails then close the opened file and return "RC_NA".
                    if(RC_Write!=RC_OK)
                    {
                        closePageFile(fHandle);
                        RC_NA;
                    }
                    //Read the requested page from the disk file and load the data to the queue's current page.
                    RC RC_Read=readBlock(pageNum, fHandle, listQueue->current->pageFrameInfo->data);
                    /* Increment the current's page's fix count by "1" as page(requested page number) is read from the disk.*/
                    listQueue->current->fixCount++;
                    //Increment the total read counter as page is read from the disk file and loaded on the buffer pool.
                    totalReadPage++;
                    //If reading fails then close the disk file and return "RC_NA".
                    if(RC_Read!=RC_OK)
                    {
                        closePageFile(fHandle);
                        return RC_NA;
                    }
                    //After successful reading, close the disk file.
                    closePageFile(fHandle);
                    //Update the current's page's dirty flag to "FALSE".
                    listQueue->current->dirtyBit=FALSE;
                    //Set current's page's LRU counter equal to maxCount + 1.
                    listQueue->current->count=maxCount+1;
                    //Update current's page's page number by the requested page number by the client.
                    listQueue->current->pageFrameInfo->pageNum=pageNum;
                    //Load the buffer pool page handler page number by the current's page's page number.
                    page->pageNum=pageNum;
                    //Load the buffer pool page handler data by the current's page's data.
                    page->data=listQueue->current->pageFrameInfo->data;
                }
            }
            //If current is tail and current's page having smallest or least LRU count.
            if(listQueue->current==listQueue->tail && listQueue->current->count==minCount)
            {
                /* Writing is performed when actually page in queue is modified and then write modified page on disk or else directly load requested page from the disk file into queue's current.*/
                RC RC_Write=writeBlock(listQueue->current->pageFrameInfo->pageNum, fHandle,
                                       listQueue->current->pageFrameInfo->data);
                //If replaced page's dirty flag was "TRUE".
                if(listQueue->current->dirtyBit==TRUE)
                {
                    //Increment the total write counter by "1" as page is written in the disk file.
                    totalWritePage++;
                }
                //If write fails then close the opened file and return "RC_NA".
                if(RC_Write!=RC_OK)
                {
                    closePageFile(fHandle);
                    RC_NA;
                }
                //Read the requested page from the disk file and load the data to the queue's current page.
                RC RC_Read=readBlock(pageNum, fHandle, listQueue->current->pageFrameInfo->data);
                //Increment the total read counter as page is read from the disk file and loaded on the buffer pool.
                listQueue->current->fixCount++;
                //Increment the total read counter as page is read from the disk file and loaded on the buffer pool.
                totalReadPage++;
                //If reading fails then close the disk file and return "RC_NA".
                if(RC_Read!=RC_OK)
                {
                    closePageFile(fHandle);
                    return RC_NA;
                }
                //After successful reading, close the disk file.
                closePageFile(fHandle);
                //Update the current's page's dirty flag to "FALSE".
                listQueue->current->dirtyBit=FALSE;
                //Set current's page's LRU counter equal to maxCount + 1.
                listQueue->current->count=maxCount+1;
                //Update current's page's page number by the requested page number by the client.
                listQueue->current->pageFrameInfo->pageNum=pageNum;
                //Load the buffer pool page handler page number by the current's page's page number.
                page->pageNum=pageNum;
                //Load the buffer pool page handler data by the current's page's data.
                page->data=listQueue->current->pageFrameInfo->data;
            }
        }
        //If succes in page replacement then return "RC_LRU_SUCCESS".
        return RC_LRU_SUCCESS;
    }
    return RC_NA; //No case suucessful.
}

/*-----------------------------------LFU Strategy-----------------------------
 * Function Name: LFU_Strategy
 *
 * Description:
 *        LFU page replacement strategy
 *
 * Parameters:
 *        BM_BufferPool * const bm: Buffer Pool Handler
 *        BM_PageHandle * const page: Buffer Page Handler
 *        PageNumber pageNum: Requested page number by the client
 *
 * Return:
 *        RC: return code
 --------------------------------------------------------------------------- */
RC LFU_Strategy(BM_BufferPool *const bm, BM_PageHandle *const page,
                const PageNumber pageNum)
{
    queue *listQueue = (queue*) bm->mgmtData;
    //If queue size is "0" or queue is empty.
    if(listQueue->queueSize==0)
    {
        //Call "FIFO_Strategy" function to add the requested page by the client.
        FIFO_Strategy(bm, page, pageNum);
        //Return "RC_OK" for success.
        return RC_OK;
    }
    //If queue size is not "0" and queue size is less than the number of pages buffer pool can accommodate.
    if(listQueue->queueSize!=0 && listQueue->queueSize<bm->numPages)
    {
        //Call "FIFO_Strategy" function to add the requested page by the client.
        FIFO_Strategy(bm, page, pageNum);
        //Return "RC_OK" for success.
        return RC_OK;
    }
    //If queue size is not "0" and queue size is more than or equal to the number of pages buffer pool can accommodate.
    if(listQueue->queueSize!=0 && listQueue->queueSize>=bm->numPages)
    {
        //Search for the minimum LFU count for the LFU page replacement strategy.
        //Declaring a fcount variable and assigning LFU count value of head's page initially.
        int fcount=listQueue->head->lfuCount;
        //For loop for searching a minimum LFU count starting from head till the node before tail.
        for(listQueue->current=listQueue->head;listQueue->current!=listQueue->tail;
            listQueue->current=listQueue->current->nextFrame)
        {
            /*If current's next's page's LFU count is minimum compared to the LFU count of current's page then, assign the current's next's page's LFU count to the fcount variable.*/
            if(fcount>listQueue->current->nextFrame->lfuCount)
            {
                fcount=listQueue->current->nextFrame->lfuCount;
            }
        }
        /* If tail's page's LFU count is minimum compared to the tail's previous page's LFU count then, assign the tail's page's LFU count to the fcount variable.*/
        if(listQueue->current==listQueue->tail && listQueue->current->lfuCount<fcount)
        {
            fcount=listQueue->current->lfuCount;
        }
        //Search for the maximum LRU count for the LRU page replacement strategy.
        //Declaring a maxCount variable and assigning count value of head's page initially.
        int maxCount=listQueue->head->count;
        //For loop for searching a maximum LRU count starting from head till the node before tail.
        for(listQueue->current=listQueue->head;listQueue->current!=listQueue->tail;
            listQueue->current=listQueue->current->nextFrame)
        {
            /* If current's next's page's LRU count is maximum compared to the LRU count of current's page then, assign the current's next's page's LRU count to the maxCount variable.*/
            if(maxCount<listQueue->current->nextFrame->count)
            {
                maxCount=listQueue->current->nextFrame->count;
            }
        }
        /* If tail's page's LRU count is maximum compared to the tail's previous page's LRU count then, assign the tail's page's LRU count to the maxCount variable.*/
        if(listQueue->current==listQueue->tail && maxCount<listQueue->tail->count)
        {
            maxCount=listQueue->tail->count;
        }
        //Search for the minimum LRU count for the LRU page replacement strategy.
        //Declaring a minCount variable and assigning LRU count value of head's page initially.
        int minCount=listQueue->head->count;
        //For loop for searching a minimum LRU count and node having minimum LFU count starting from head till the node before tail.
        for(listQueue->current=listQueue->head;listQueue->current!=listQueue->tail &&
            listQueue->current->lfuCount==fcount;
            listQueue->current=listQueue->current->nextFrame)
        {
            /* If current's next's page's LRU count is minimum compared to the LRU count of current's page and node having minimum LFU count then, assign the current's next's page's LRU count to the minCount variable.*/
            if(minCount>listQueue->current->nextFrame->count && listQueue->current->nextFrame->lfuCount==fcount)
            {
                minCount=listQueue->current->nextFrame->count;
            }
        }
        /* If tail's page's LRU count is minimum compared to the tail's previous page's LRU count and node having minimum LFU count then, assign the tail's page's LRU count to the minCount variable.*/
        if(listQueue->current==listQueue->tail && listQueue->current->lfuCount==fcount &&
           minCount>listQueue->tail->count)
        {
            minCount=listQueue->tail->count;
        }
        /* Search wether requested page number is already present in the queue or in the buffer pool or not by calling "seekPage" function.*/
        RC RC_Search=seekPage(bm, page, pageNum);
        /* If search is successful then increase the current's page's LRU counter by maxCount+1, increase the current's page's fix count by "1" and increase the current's page's LFU count by "1".*/
        if(RC_Search==RC_OK)
        {
            listQueue->current->count=maxCount+1;
            listQueue->current->lfuCount=(listQueue->current->lfuCount)+1;
            listQueue->current->fixCount+=1;
        }
        /* If search is unsuccessful then, page having smallest LRU count and smallest LFU count is written back to the disk file and read the requested page number from the disk file to that page whose content has been written back to the disk file.*/
        if(RC_Search==RC_NA)
        {
            /*For loop for searching page having smallest LRU count and smallest LFU count in the buffer pool through queue.*/
            for(listQueue->current=listQueue->head;listQueue->current!=listQueue->tail;
                listQueue->current=listQueue->current->nextFrame)
            {
                /* If current's page's LRU count is minimum and LFU count is minimum, then write the page in the disk file.*/
                if(listQueue->current->lfuCount==fcount && listQueue->current->count==minCount)
                {
                    /* Writing is performed when actually page in queue is modified and then write modified page on disk or else directly load requested page from the disk file into queue's current.*/
                    RC RC_Write=writeBlock(listQueue->current->pageFrameInfo->pageNum, fHandle,
                                           listQueue->current->pageFrameInfo->data);
                    //If replaced page's dirty flag was "TRUE".
                    if(listQueue->current->dirtyBit==TRUE)
                    {
                        //Increment the total write counter by "1" as page is written in the disk file.
                        totalWritePage++;
                    }
                    //If write fails then close the opened file and return "RC_NA".
                    if(RC_Write!=RC_OK)
                    {
                        closePageFile(fHandle);
                        RC_NA;
                    }
                    //Read the requested page from the disk file and load the data to the queue's current page.
                    RC RC_Read=readBlock(pageNum, fHandle, listQueue->current->pageFrameInfo->data);
                    /* Increment the current's page's fix count by "1" as page(requested page number) is read from the disk.*/
                    listQueue->current->fixCount++;
                    //Increment the total read counter as page is read from the disk file and loaded on the buffer pool.
                    totalReadPage++;
                    //If reading fails then close the disk file and return "RC_NA".
                    if(RC_Read!=RC_OK)
                    {
                        closePageFile(fHandle);
                        return RC_NA;
                    }
                    //After successful reading, close the disk file.
                    closePageFile(fHandle);
                    //Update the current's page's dirty flag to "FALSE".
                    listQueue->current->dirtyBit=FALSE;
                    //Set current's page's LRU counter equal to maxCount + 1.
                    listQueue->current->count=maxCount+1;
                    //Set current's page's LFU counter equal to "1".
                    listQueue->current->lfuCount=1;
                    //Update current's page's page number by the requested page number by the client.
                    listQueue->current->pageFrameInfo->pageNum=pageNum;
                    //Load the buffer pool page handler page number by the current's page's page number.
                    page->pageNum=pageNum;
                    //Load the buffer pool page handler data by the current's page's data.
                    page->data=listQueue->current->pageFrameInfo->data;
                }
            }
            //If current is tail and current's page having smallest or least LRU count and having smallest LFU count.
            if(listQueue->current==listQueue->tail && listQueue->current->lfuCount==fcount &&
               listQueue->current->count==minCount)
            {
                /* Writing is performed when actually page in queue is modified and then write modified page on disk or else directly load requested page from the disk file into queue's current.*/
                RC RC_Write=writeBlock(listQueue->current->pageFrameInfo->pageNum, fHandle,
                                       listQueue->current->pageFrameInfo->data);
                //If replaced page's dirty flag was "TRUE".
                if(listQueue->current->dirtyBit==TRUE)
                {
                    //Increment the total write counter by "1" as page is written in the disk file.
                    totalWritePage++;
                }
                //If write fails then close the opened file and return "RC_NA".
                if(RC_Write!=RC_OK)
                {
                    closePageFile(fHandle);
                    RC_NA;
                }
                //Read the requested page from the disk file and load the data to the queue's current page.
                RC RC_Read=readBlock(pageNum, fHandle, listQueue->current->pageFrameInfo->data);
                /* Increment the current's page's fix count by "1" as page(requested page number) is read from the disk.*/
                listQueue->current->fixCount++;
                //Increment the total read counter as page is read from the disk file and loaded on the buffer pool.
                totalReadPage++;
                //If reading fails then close the disk file and return "RC_NA".
                if(RC_Read!=RC_OK)
                {
                    closePageFile(fHandle);
                    return RC_NA;
                }
                //After successful reading, close the disk file.
                closePageFile(fHandle);
                //Update the current's page's dirty flag to "FALSE".
                listQueue->current->dirtyBit=FALSE;
                //Set current's page's LRU counter equal to maxCount + 1.
                listQueue->current->count=maxCount+1;
                //Set current's page's LFU counter equal to "1".
                listQueue->current->lfuCount=1;
                //Update current's page's page number by the requested page number by the client.
                listQueue->current->pageFrameInfo->pageNum=pageNum;
                //Load the buffer pool page handler page number by the current's page's page number.
                page->pageNum=pageNum;
                //Load the buffer pool page handler data by the current's page's data.
                page->data=listQueue->current->pageFrameInfo->data;
            }
        }
        //Return "RC_OK" on success.
        return RC_OK;
    }
    return RC_NA; //No case is successful.
}

/*-----------------------------------CLOCK Strategy-----------------------------
 * Function Name: CLOCK_Strategy
 *
 * Description:
 *        CLOCK page replacement strategy
 *
 * Parameters:
 *        BM_BufferPool * const bm: Buffer Pool Handler
 *        BM_PageHandle * const page: Buffer Pool Page Handler
 *        PageNumber pageNum: Requested page number by the client
 *
 * Return:
 *        RC: return code
 --------------------------------------------------------------------------- */
RC CLOCK_Strategy(BM_BufferPool *const bm, BM_PageHandle *const page,
                  const PageNumber pageNum)
{
    queue *listQueue = (queue*) bm->mgmtData;
    //If queue size is "0" or queue is empty.
    if(listQueue->queueSize==0)
    {
        //Call "FIFO_Strategy" function to add the requested page by the client.
        FIFO_Strategy(bm, page, pageNum);
        //Return "RC_OK" for success.
        return RC_OK;
    }
    //If queue size is not "0" and queue size is less than the number of pages buffer pool can accommodate.
    if(listQueue->queueSize!=0 && listQueue->queueSize<bm->numPages)
    {
        //Call "FIFO_Strategy" function to add the requested page by the client.
        FIFO_Strategy(bm, page, pageNum);
        //Return "RC_OK" for success.
        return RC_OK;
    }
    //If queue size is not "0" and queue size is more than or equal to the number of pages buffer pool can accommodate.
    if(listQueue->queueSize!=0 && listQueue->queueSize>=bm->numPages)
    {
        //Search for the maximum LRU count for the LRU page replacement strategy.
        //Declaring a maxCount variable and assigning count value of head's page initially.
        int maxCount=listQueue->head->count;
        //For loop for searching a maximum LRU count starting from head till the node before tail.
        for(listQueue->current=listQueue->head;listQueue->current!=listQueue->tail;
            listQueue->current=listQueue->current->nextFrame)
        {
            /* If current's next's page's LRU count is maximum compared to the LRU count of current's page then, assign the current's next's page's LRU count to the maxCount variable.*/
            if(maxCount<listQueue->current->nextFrame->count)
            {
                maxCount=listQueue->current->nextFrame->count;
            }
        }
        /* If tail's page's LRU count is maximum compared to the tail's previous page's LRU count then, assign the tail's page's LRU count to the maxCount variable.*/
        if(listQueue->current==listQueue->tail && maxCount<listQueue->tail->count)
        {
            maxCount=listQueue->tail->count;
        }
        //Search for the minimum LRU count for the LRU page replacement strategy.
        //Declaring a minCount variable and assigning LRU count value of head's page initially.
        int minCount=listQueue->head->count;
        //For loop for searching a minimum LRU count and node having minimum LFU count starting from head till the node before tail.
        for(listQueue->current=listQueue->head;listQueue->current!=listQueue->tail;
            listQueue->current=listQueue->current->nextFrame)
        {
            /* If current's next's page's LRU count is minimum compared to the LRU count of current's page then, assign the current's next's page's LRU count to the minCount variable.*/
            if(minCount>listQueue->current->nextFrame->count)
            {
                minCount=listQueue->current->nextFrame->count;
            }
        }
        /* If tail's page's LRU count is minimum compared to the tail's previous page's LRU count   then, assign the tail's page's LRU count to the minCount variable.*/
        if(listQueue->current==listQueue->tail && minCount>listQueue->tail->count)
        {
            minCount=listQueue->tail->count;
        }
        /* Search wether requested page number is already present in the queue or in the buffer pool or not by calling "seekPage" function.*/
        RC RC_Search=seekPage(bm, page, pageNum);
        //If search is successful then check for the clock bit.
        if(RC_Search==RC_OK)
        {
            //If clock bit is "0".
            if(listQueue->current->clockBit==0)
            {
                //Set current's page's LRU counter equal to maxCount + 1.
                listQueue->current->count=maxCount+1;
                //Set current's page's clock bit to "1".
                listQueue->current->clockBit=1;
                /* Increment the current's page's fix count by "1" as page(requested page number) is read from the disk.*/
                listQueue->current->fixCount+=1;
                //Set the "maxCount" variable value to current's page's LRU count.
                maxCount=listQueue->current->count;
                //Set current as head.
                listQueue->current=listQueue->head;
                /*Move current to the page where it was before searching from the disk file by checking current's page's LRU count is "maxCount-1".*/
                //If while condition does not satisfy then move current to next of current.
                while(listQueue->current!=listQueue->tail && listQueue->current->count!=maxCount-1)
                {
                    listQueue->current=listQueue->current->nextFrame;
                }
            }
            //If clock bit is "1".
            else
            {
                //Set current's page's LRU counter equal to maxCount + 1.
                listQueue->current->count=maxCount+1;
                /* Increment the current's page's fix count by "1" as page(requested page number) is read from the disk.*/
                listQueue->current->fixCount+=1;
                //Added: Set the "maxCount" variable value to current's page's LRU count.
                maxCount=listQueue->current->count;
                //Set current as head.
                listQueue->current=listQueue->head;
                /* Move current to the page where it was before searching from the disk file by checking current's page's LRU count is "maxCount-1".*/
                //If while condition does not satisfy then move current to next of current.
                while(listQueue->current!=listQueue->tail && listQueue->current->count!=maxCount-1)
                {
                    listQueue->current=listQueue->current->nextFrame;
                }
            }
            //Return "RC_OK" on success.
            return RC_OK;
        }
        //If search is unsuccessful.
        if(RC_Search==RC_NA)
        {
            /* Move current to the most recently used page. Most recently used page can be found by getting maximum LRU count of available pages in the buffer pool.*/
            while(listQueue->current->count!=maxCount)
            {
                if(listQueue->current->nextFrame==NULL)
                {
                    listQueue->current=listQueue->head;
                }
                else
                {
                    listQueue->current=listQueue->current->nextFrame;
                }
            }
            /* Update clock bit to "0" till next "0" clock bit value is found for a page and if next page with "0" clock bit value is found then move current to that page. By doing this we can replace the current's page in the buffer pool.*/
            //If current is tail and head's page's clock bit is "1".
            if(listQueue->current==listQueue->tail && listQueue->head->clockBit!=0)
            {
                listQueue->current=listQueue->head;
                listQueue->current->clockBit=0;
                while(listQueue->current->nextFrame!= listQueue->tail && listQueue->current->nextFrame->clockBit==1)
                {
                    listQueue->current=listQueue->current->nextFrame;
                    listQueue->current->clockBit=0;
                }
                if(listQueue->current->nextFrame== listQueue->tail && listQueue->current->nextFrame->clockBit==1)
                {
                    listQueue->current=listQueue->current->nextFrame;
                    listQueue->current->clockBit=0;
                    listQueue->current=listQueue->head;
                    while(listQueue->current->nextFrame!= listQueue->tail && listQueue->current->nextFrame->clockBit==1)
                    {
                        listQueue->current=listQueue->current->nextFrame;
                        listQueue->current->clockBit=0;
                    }
                }
                if((listQueue->current->nextFrame->clockBit==0 && (listQueue->current->nextFrame->count<
                                                                   listQueue->current->count))|| (listQueue->current->nextFrame== listQueue->tail &&
                                                                                                  listQueue->current->nextFrame->clockBit==0))
                {
                    listQueue->current=listQueue->current->nextFrame;
                }
            }
            //If current is tail and head's page's clock bit is "0" then, move current to head.
            else if(listQueue->current==listQueue->tail && listQueue->head->clockBit==0)
            {
                listQueue->current=listQueue->head;
            }
            //If current is not tail and current's next's page's clock bit is "1".
            else if(listQueue->current!=listQueue->tail && listQueue->current->nextFrame->clockBit!=0)
            {
                //
                listQueue->current=listQueue->current->nextFrame;
                listQueue->current->clockBit=0;
                //stop? after updating current, it should not move to next and upadate clockbit as 0 as we are not changing the current if we want to replace
                while(listQueue->current->nextFrame!= listQueue->tail && listQueue->current->nextFrame->clockBit==1)
                {
                    listQueue->current=listQueue->current->nextFrame;
                    listQueue->current->clockBit=0;
                }
                if(listQueue->current->nextFrame== listQueue->tail && listQueue->current->nextFrame->clockBit==1)
                {
                    listQueue->current=listQueue->current->nextFrame;
                    listQueue->current->clockBit=0;
                    listQueue->current=listQueue->head;
                    while(listQueue->current->nextFrame!= listQueue->tail && listQueue->current->nextFrame->clockBit==1)
                    {
                        listQueue->current=listQueue->current->nextFrame;
                        listQueue->current->clockBit=0;
                    }
                }
                if((listQueue->current->nextFrame->clockBit==0 && (listQueue->current->nextFrame->count<
                                                                   listQueue->current->count))||
                   (listQueue->current->nextFrame== listQueue->tail &&
                    listQueue->current->nextFrame->clockBit==0))
                {
                    listQueue->current=listQueue->current->nextFrame;
                }
            }
            //If current is not tail and current's next's page's clock bit is "0" then, move current to current's next.
            else if(listQueue->current!=listQueue->tail && listQueue->current->nextFrame->clockBit==0)
            {
                listQueue->current=listQueue->current->nextFrame;
            }
            /* Writing is performed when actually page in queue is modified and then write modified page on disk or else directly load requested page from the disk file into queue's current.*/
            RC RC_Write=writeBlock(listQueue->current->pageFrameInfo->pageNum, fHandle,
                                   listQueue->current->pageFrameInfo->data);
            //If replaced page's dirty flag was "TRUE".
            if(listQueue->current->dirtyBit==TRUE)
            {
                //Increment the total write counter by "1" as page is written in the disk file.
                totalWritePage++;
            }
            //If write fails then close the opened file and return "RC_NA".
            if(RC_Write!=RC_OK)
            {
                closePageFile(fHandle);
                RC_NA;
            }
            //Read the requested page from the disk file and load the data to the queue's current page.
            RC RC_Read=readBlock(pageNum, fHandle, listQueue->current->pageFrameInfo->data);
            /* Increment the current's page's fix count by "1" as page(requested page number) is read from the disk.*/
            listQueue->current->fixCount++;
            //Increment the total read counter as page is read from the disk file and loaded on the buffer pool.
            totalReadPage++;
            //If reading fails then close the disk file and return "RC_NA".
            if(RC_Read!=RC_OK)
            {
                closePageFile(fHandle);
                return RC_NA;
            }
            //After successful reading, close the disk file.
            closePageFile(fHandle);
            //Update the current's page's dirty flag to "FALSE".
            listQueue->current->dirtyBit=FALSE;
            //Set current's page's LRU counter equal to maxCount + 1.
            listQueue->current->count=maxCount+1;
            //Set the clock bit to "1".
            listQueue->current->clockBit=1;
            //Set current's page's LFU counter equal to "1".
            listQueue->current->lfuCount=1;
            //Update current's page's page number by the requested page number by the client.
            listQueue->current->pageFrameInfo->pageNum=pageNum;
            //Load the buffer pool page handler page number by the current's page's page number.
            page->pageNum=pageNum;
            //Load the buffer pool page handler data by the current's page's data.
            page->data=listQueue->current->pageFrameInfo->data;
            //Return "RC_OK" on success.
            return RC_OK;
        }
    }
    return RC_NA; //No case is suucessful.
}

/*---------------------------------Pin Page-------------------------------------
 * Function Name: pinPage
 *
 * Description:
 *        Pin the page i.e. load the page in buffer pool with the requested page number from the disk file if the
 *        requested page is not found in the buffer pool.
 *
 * Parameters:
 *        BM_BufferPool * const bm: Buffer Pool Handler
 *        BM_PageHandle * const page: Buffer Pool Page Handler
 *        PageNumber pageNum: Requested page number by the client
 *
 * Return:
 *        RC: return code
 ------------------------------------------------------------------------------*/
RC pinPage (BM_BufferPool *const bm, BM_PageHandle *const page,
            const PageNumber pageNum)
{
    //If buffer pool has no pages or some invalid page number then return "RC_NO_PAGES".
    if(bm->numPages == 0 || bm->numPages<0)
    {
        RC_message="No pages in the buffer pool or incorrect pages!";
        return RC_NO_PAGES;
    }
    /*If buffer pool has pages to accommodate the requested page then check for the page replacemen strategy and load or replace th page in the buffer pool accordingly. */
    else
    {
        //Pass startegy name in the switch case.
        switch (bm->strategy)
        {
            case RS_FIFO:
                FIFO_Strategy(bm,page,pageNum);
                break;
            case RS_LRU:
                LRU_Strategy(bm,page,pageNum);
                break;
            case RS_LFU:
                LFU_Strategy(bm,page,pageNum);
                break;
            case RS_CLOCK:
                CLOCK_Strategy(bm,page,pageNum);
                break;
                //If any page replacement strategy comes apart from the FIFO, LRU, LFU and CLOCK.
            default:
                printf("%i startegy is not implemented!", bm->strategy);
                break;
        }
        //Return "RC_OK" for success.
        return RC_OK;
    }
}

/*----------------------------------Mark Dirty-----------------------------------
 * Function Name: markDirty
 *
 * Description:
 *        Mark the requested page as dirty.
 *
 * Parameters:
 *        BM_BufferPool * const bm: Buffer Pool Handler
 *        BM_PageHandle * const page: Buffer Pool Page Handler
 *
 * Return:
 *        RC: return code
 -------------------------------------------------------------------------------*/
RC markDirty (BM_BufferPool *const bm, BM_PageHandle *const page)
{
    queue *listQueue = (queue*) bm->mgmtData;
    //Search for the requested page number in the queue or in the buffer pool by calling "seekPage" function.
    RC RC_Search = seekPage(bm,page,page->pageNum);
    //If search fails then return "RC_NA".
    if (RC_Search != RC_OK)
    {
        return RC_NA;
    }
    //If search is successful then set current's page's dirt bit to "TRUE" and return "RC_OK".
    else
    {
        listQueue->current->dirtyBit=TRUE;
        return RC_OK;
    }
}

/*--------------------------------Unpin Page--------------------------------
 *  Function Name: unpinPage
 *
 * Description:
 *        Unpin a page.
 *
 * Parameters:
 *        BM_BufferPool * const bm: Buffer Pool Handler
 *        BM_PageHandle * const page: Buffer Pool Page Handler
 *
 * Return:
 *        RC: return code
 ------------------------------------------------------------------------- */
RC unpinPage (BM_BufferPool *const bm, BM_PageHandle *const page)
{
    queue *listQueue = (queue*) bm->mgmtData;
    //Search for the requested page number in the queue or in the buffer pool by calling "seekPage" function.
    RC RC_Search = seekPage(bm,page,page->pageNum);
    //If search fails then return "RC_NA".
    if (RC_Search!=RC_OK)
    {
        return RC_NA;
    }
    //If search is successful then decrement current's page's fix count by "1" and return "RC_OK".
    listQueue->current->fixCount-=1;
    return RC_OK;
}

/*-------------------------------Force Page------------------------------
 * Function Name: forcePage
 *
 * Description:
 *        Write the requested page back to the page file on disk.
 *
 * Parameters:
 *        BM_BufferPool * const bm: Buffer Pool Handler
 *        BM_PageHandle * const page: Buffer Pool Page Handler
 *
 * Return:
 *        RC: return code
 ------------------------------------------------------------------------*/
RC forcePage (BM_BufferPool *const bm, BM_PageHandle *const page)
{
    queue *listQueue=(queue*) bm->mgmtData;
    //Open the disk file to write the page from buffer pool to it.
    openPageFile(bm->pageFile, fHandle);
    //Write the page to the disk file.
    RC RC_Write=writeBlock(page->pageNum,fHandle,page->data);
    //Increment the total write counter by "1" as page is written in the disk file.
    totalWritePage++;
    //If write fails then return "RC_NA".
    if(RC_Write!=RC_OK)
    {
        closePageFile(fHandle);
        RC_NA;
    }
    //Set current's dirty bit to "FALSE".
    listQueue->current->dirtyBit=FALSE;
    //Close the file.
    closePageFile(fHandle);
    //Return "RC_OK" on success.
    return RC_OK;
}

/*---------------------------------Force Flush Pool------------------------
 * Function Name: forceFlushPool
 *
 * Description:
 *        Write back the data of all dirty pages in the Buffer Pool.
 *
 * Parameters:
 *        BM_BufferPool *const bm: Buffer Pool Handler
 *
 * Return:
 *        RC: return code
 --------------------------------------------------------------------------*/
RC forceFlushPool(BM_BufferPool *const bm)
{
    queue *listQueue=(queue*) bm->mgmtData;
    //Open the disk file to write the page from buffer pool to it.
    openPageFile(bm->pageFile, fHandle);
    /* Write all the pages from buffer pool that comes before tail to the disk file whose fix count is "0" and dirty bit is "TRUE".*/
    for(listQueue->current=listQueue->head;listQueue->current!=listQueue->tail;
        listQueue->current=listQueue->current->nextFrame)
    {
        if(listQueue->current->fixCount==0 && listQueue->current->dirtyBit==TRUE)
        {
            //Write page on disk file.
            RC RC_Write=writeBlock(listQueue->current->pageFrameInfo->pageNum, fHandle,
                                   listQueue->current->pageFrameInfo->data);
            //Increment the total write counter by "1" as page is written in the disk file.
            totalWritePage++;
            //If write fails then close the opened file and return "RC_NA".
            if(RC_Write!=RC_OK)
            {
                closePageFile(fHandle);
                RC_NA;
            }
            //Set dirty bit to "FALSE".
            listQueue->current->dirtyBit=FALSE;
        }
    }
    //Write tail's page from buffer pool to the disk file if fix count is "0" and dirty bit is "TRUE".*/
    if(listQueue->current==listQueue->tail && listQueue->current->fixCount==0 &&
       listQueue->current->dirtyBit==TRUE)
    {
        //Write page on disk file.
        RC RC_Write=writeBlock(listQueue->current->pageFrameInfo->pageNum, fHandle,
                               listQueue->current->pageFrameInfo->data);
        //Increment the total write counter by "1" as page is written in the disk file.
        totalWritePage++;
        //If write fails then close the opened file and return "RC_NA".
        if(RC_Write!=RC_OK)
        {
            closePageFile(fHandle);
            RC_NA;
        }
        //Set dirty bit to "FALSE".
        listQueue->current->dirtyBit=FALSE;
    }
    //Close the file after writing is done successfully.
    closePageFile(fHandle);
    //Return "RC_OK" on success.
    return RC_OK;
}

/*------------------------------Shutdown Buffer Pool-----------------------
 * Function Name: shutdownBufferPool
 *
 * Description:
 *        Shut down the Buffer Pool.
 *
 * Parameters:
 *        BM_BufferPool *const bm: Buffer Pool Handler
 *
 * Return:
 *        RC: return code
 --------------------------------------------------------------------------*/
RC shutdownBufferPool(BM_BufferPool *const bm)
{
    queue *listQueue=(queue*) bm->mgmtData;
    /* Call "forceFlushPool" function in case if any pages are available in the buffer pool before shutting down the buffer pool.*/
    RC RC_Force=forceFlushPool(bm);
    //If force flush pool is success the free the memory used.
    if(RC_Force==RC_OK)
    {
        free(listQueue->current->pageFrameInfo->data);
        free(listQueue->current->pageFrameInfo);
        free(listQueue);
        //Return "RC_OK" on success.
        return RC_OK;
    }
    return RC_NA; //No success
}

/*------------------------------Get Frame Contents------------------------------
 * Function Name: getFrameContents
 *
 * Description:
 *         Returns an array of PageNumbers (of size numPages)
 *         An empty page frame is represented using the constant NO_PAGE
 *
 * Parameters:
 *        BM_BufferPool *const bm: Buffer Pool Handler
 *
 * Return:
 *        PageNumber *: an array of PageNumber of size numPages
 ------------------------------------------------------------------------------*/
PageNumber *getFrameContents (BM_BufferPool *const bm)
{
    //Declare and allocate memory to a pointer of type "PageNumber".
    PageNumber *framePageNums= (PageNumber*)malloc(sizeof(PageNumber)*bm->numPages);
    queue *listQueue=(queue*) bm->mgmtData;
    int i=0;
    int j=0;
    //When queue is empty then store "-1" value.
    if(listQueue->queueSize==0)
    {
        framePageNums[i]=listQueue->head->pageFrameInfo->pageNum;
        i++;
    }
    //When queue or buffer pool is having some pages then store those page numbers.
    else
    {
        for(listQueue->current=listQueue->head;listQueue->current!=listQueue->tail;
            listQueue->current=listQueue->current->nextFrame)
        {
            framePageNums[i]=listQueue->current->pageFrameInfo->pageNum;
            i++;
        }
        if(listQueue->current==listQueue->tail)
        {
            framePageNums[i]=listQueue->tail->pageFrameInfo->pageNum;
            i++;
        }
        
    }
    //If pages are less than the buffer pool capacity then store "-1" for empty page frame.
    j=bm->numPages;
    if(i<j)
    {
        while(i<j)
        {
            //NO_PAGE value is "-1".
            framePageNums[i]=NO_PAGE;
            i++;
        }
    }
    //Return pointer.
    return framePageNums;
}

/*--------------------------------Get Dirty Flags----------------------------
 * Function Name: getDirtyFlags
 *
 * Description:
 *         Returns an array of bools (of size numPages)
 *         Empty page frames are considered as clean
 *
 * Parameters:
 *        BM_BufferPool *const bm: Buffer Pool Handler
 *
 * Return:
 *        bool *: an array of bools indicating each page is dirty or not
 ----------------------------------------------------------------------------*/
bool *getDirtyFlags (BM_BufferPool *const bm)
{
    //Declare and allocate memory to a pointer of type "bool".
    bool *dirtyFrames=(bool*)malloc(sizeof(bool)*bm->numPages);
    queue *listQueue=(queue*) bm->mgmtData;
    int i=0;
    int j=0;
    //When queue is empty then store dirty bit as "FASLE".
    if(listQueue->queueSize==0)
    {
        dirtyFrames[i]=listQueue->head->dirtyBit;
        i++;
    }
    //When queue or buffer pool is having some pages then store those page's dirty bit value.
    else
    {
        for(listQueue->current=listQueue->head;listQueue->current!=listQueue->tail;
            listQueue->current=listQueue->current->nextFrame)
        {
            dirtyFrames[i]=listQueue->current->dirtyBit;
            i++;
        }
        if(listQueue->current==listQueue->tail)
        {
            dirtyFrames[i]=listQueue->tail->dirtyBit;
            i++;
        }
    }
    //If pages are less than the buffer pool capacity then store dirty bit as "FALSE" for empty page frame.
    j=bm->numPages;
    if(i<j)
    {
        while(i<j)
        {
            //Set dirty bit to "FALSE".
            dirtyFrames[i]=FALSE;
            i++;
        }
    }
    //Return pointer.
    return dirtyFrames;
}

/*--------------------------------Get Fix Counts----------------------------
 * Function Name: getFixCounts
 *
 * Description:
 *         Returns an array of ints (of size numPages)
 *
 * Parameters:
 *        BM_BufferPool *const bm: Buffer Pool Handler
 *
 * Return:
 *        int pointer: An array of fix count of each pages in the Buffer Pool.
 --------------------------------------------------------------------------*/
int *getFixCounts (BM_BufferPool *const bm)
{
    //Declare and allocate memory to a pointer of type "int".
    int *frameFixCount=(int*)malloc(sizeof(int)*bm->numPages);
    queue *listQueue=(queue*) bm->mgmtData;
    int i=0;
    int j=0;
    //When queue is empty then store fix count as "0".
    if(listQueue->queueSize==0)
    {
        frameFixCount[i]=listQueue->head->fixCount;
        i++;
    }
    //When queue or buffer pool is having some pages then store those page's fix count.
    else
    {
        for(listQueue->current=listQueue->head;listQueue->current!=listQueue->tail;
            listQueue->current=listQueue->current->nextFrame)
        {
            frameFixCount[i]=listQueue->current->fixCount;
            i++;
        }
        if(listQueue->current==listQueue->tail)
        {
            frameFixCount[i]=listQueue->tail->fixCount;
            i++;
        }
    }
    //If pages are less than the buffer pool capacity then store fix count as "0" for empty page frame.
    j=bm->numPages;
    if(i<j)
    {
        while(i<j)
        {
            frameFixCount[i]=0;
            i++;
        }
    }
    //Return pointer.
    return frameFixCount;
}

/*----------------------------------Get Read Pages-------------------------------
 * Function Name: getNumReadIO
 *
 * Description:
 *        Return the total number of pages read since the Buffer Pool has been initialized.
 *
 * Parameters:
 *        BM_BufferPool *const bm: Buffer Pool Handler
 *
 * Return:
 *        integer value: The number of pages read from the disk file or page file since buffer pool was initialized.
 -------------------------------------------------------------------------------*/
int getNumReadIO (BM_BufferPool *const bm)
{
    return totalReadPage;
}

/*------------------------------Get Written Pages----------------------------------
 * Function Name: getNumWriteIO
 *
 * Description:
 *        Return the total number of pages written since the Buffer Pool has been initialized.
 *
 * Parameters:
 *        BM_BufferPool *const bm: Buffer Pool` Handler
 *
 * Return:
 *        integer value: the number of pages written to the disk file or page file since buffer pool was initialized.
 ---------------------------------------------------------------------------------*/
int getNumWriteIO (BM_BufferPool *const bm)
{
    return totalWritePage;
}
