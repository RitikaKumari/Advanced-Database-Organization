//
//  buffer_mgr_stat.h
//  Assignment 1
//
//  Created by Viraj Desai on 3/14/18.
//  Copyright © 2018 Viraj Desai. All rights reserved.
//

#ifndef BUFFER_MGR_STAT_H
#define BUFFER_MGR_STAT_H

#include "buffer_mgr.h"

// debug functions
void printPoolContent (BM_BufferPool *const bm);
void printPageContent (BM_PageHandle *const page);
char *sprintPoolContent (BM_BufferPool *const bm);
char *sprintPageContent (BM_PageHandle *const page);

#endif

