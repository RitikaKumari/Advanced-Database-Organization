#ifndef RECORD_MGR_H
#define RECORD_MGR_H

#include "dberror.h"
#include "expr.h"
#include "tables.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "buffer_mgr.h"
#include "dt.h"
#include "record_mgr.h"
#include "storage_mgr.h"
#include "expr.h"
//#include "rm_serializer.c"

#define TABLE_INFO_PAGE 0
#define FIRST_RESERVED_PAGE 1

#define RESERVED_PAGE_HEADER 96
#define RESERVED_PAGE_CAPACITY \
sizeof(char) * 8 * (PAGE_SIZE - RESERVED_PAGE_HEADER)


// Bookkeeping for scans
typedef struct RM_ScanHandle
{
    RM_TableData *rel;
    void *mgmtData;
} RM_ScanHandle;

 typedef struct RM_ScanCondition {
 Expr *cond;
 RID *id;
 } RM_ScanCondition;

RM_TableData *REL = NULL;
//PageNumber reservedPageNum;
// table and manager
extern RC initRecordManager (void *mgmtData);
extern RC shutdownRecordManager();
extern RC createTable (char *name, Schema *schema);
extern RC openTable (RM_TableData *rel, char *name);
extern RC closeTable (RM_TableData *rel);
extern RC deleteTable (char *name);
extern int getNumTuples (RM_TableData *rel);

// handling records in a table
extern RC insertRecord (RM_TableData *rel, Record *record);
extern RC deleteRecord (RM_TableData *rel, RID id);
extern RC updateRecord (RM_TableData *rel, Record *record);
extern RC getRecord (RM_TableData *rel, RID id, Record *record);

// scans
extern RC startScan (RM_TableData *rel, RM_ScanHandle *scan, Expr *cond);
extern RC next (RM_ScanHandle *scan, Record *record);
extern RC closeScan (RM_ScanHandle *scan);

// dealing with schemas
extern int getRecordSize (Schema *schema);
extern Schema *createSchema (int numAttr, char **attrNames, DataType *dataTypes, int *typeLength, int keySize, int *keys);
extern RC freeSchema (Schema *schema);

// dealing with records and attribute values
extern RC createRecord (Record **record, Schema *schema);
extern RC freeRecord (Record *record);
extern RC getAttr (Record *record, Schema *schema, int attrNum, Value **value);
extern RC setAttr (Record *record, Schema *schema, int attrNum, Value *value);

//RM_TableData *REL = NULL; // done by me
// prototypes
//RC initRecordManager(void *mgmtData);
//RC shutdownRecordManager();
RC initTableInfoPage();
//RC createTable(char *name, Schema *schema);
//RC openTable(RM_TableData *rel, char *name);
//RC closeTable(RM_TableData *rel);
//RC deleteTable(char *name);
int getRecordLength(RM_TableData *rel);
int getTotalRecords(RM_TableData *rel);
RC setTotalRecords(RM_TableData *rel, int value);
int getTotalPages(RM_TableData *rel);
RC setTotalPages(RM_TableData *rel, int value);
int getPageMaxRecords(RM_TableData *rel);
int getNumTuples(RM_TableData *rel);
RC checkRID(RM_TableData *rel, RID id);
PageNumber getReservedPageNum(PageNumber pageNum);
bool isPageFree(RM_TableData *rel, PageNumber reservedPageNum,PageNumber pageNum);
bool getBit(char *data, int bitOffset);
RC setBit(char *data, int bitOffset, bool value);
RC createReservedPage(RM_TableData *rel, PageNumber reservedPageNum);
RC updateReservedPage(RM_TableData *rel, PageNumber reservedPageNum,PageNumber pageNum, bool value);
PageNumber getFirstFreePage(RM_TableData *rel, PageNumber reservedPageNum);
RC setFirstFreePage(RM_TableData *rel, PageNumber reservedPageNum, int value);
PageNumber getNextReservedPage(RM_TableData *rel, PageNumber reservedPageNum);
RC setNextReservedPage(RM_TableData *rel, PageNumber reservedPageNum, int value);
PageNumber getPrevReservedPage(RM_TableData *rel, PageNumber reservedPageNum);
RC setPrevReservedPage(RM_TableData *rel, PageNumber reservedPageNum, int value);
PageNumber searchFirstFreePage(RM_TableData *rel);
bool isPageInitialized(RM_TableData *rel, PageNumber pageNum);
RC setPageInitialized(RM_TableData *rel, PageNumber pageNum, bool value);
PageNumber getCurrentRecords(RM_TableData *rel, PageNumber pageNum);
RC setCurrentRecords(RM_TableData *rel, PageNumber pageNum, int value);
bool isSlotOccupied(RM_TableData *rel, PageNumber pageNum, int slotId);
RC setSlotOccupied(RM_TableData *rel, PageNumber pageNum, int slotId,bool value);
RC checkRecordLength(RM_TableData *rel, char *recordData);
RC initRecordPage(RM_TableData *rel, PageNumber pageNum);
int getFreeSlotId(RM_TableData *rel, PageNumber pageNum);
//RC insertRecord(RM_TableData *rel, Record *record);
//RC deleteRecord(RM_TableData *rel, RID id);
//RC updateRecord(RM_TableData *rel, Record *record);
//RC getRecord(RM_TableData *rel, RID id, Record *record);
//RC startScan(RM_TableData *rel, RM_ScanHandle *scan, Expr *cond);
//RC next(RM_ScanHandle *scan, Record *record);
//RC closeScan(RM_ScanHandle *scan);
int getRecordSize(Schema *schema);
char *schemaToString(Schema * schema);
//Schema *createSchema(int numAttr, char **attrNames, DataType *dataTypes,int *typeLength,int keySize, int *keys);
//RC freeSchema(Schema *schema);
//RC createRecord(Record **record, Schema *schema);
//RC freeRecord(Record *record);
//RC getAttr(Record *record, Schema *schema, int attrNum, Value **value);
//RC setAttr(Record *record, Schema *schema, int attrNum, Value *value);

#endif // RECORD_MGR_H
