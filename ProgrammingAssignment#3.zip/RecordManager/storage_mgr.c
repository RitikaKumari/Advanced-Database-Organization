#include<stdio.h>
#include<stdlib.h>
#include"storage_mgr.h"
#include"dberror.h"

//File pointer declaration
FILE *fp;

/*-----------------------Initialize Storage Manager---------------------------------
 * Method Name: initStorageManager
 *
 * Description: NA
 *
 * Parameter: void
 *
 * Return: NA
 -------------------------------------------------------------------------*/
extern void initStorageManager (void)
{
    
}

/*-----------------------Create Page File---------------------------------
 * Method Name: createPageFile
 *
 * Description: CreatePageFile method creates a new page file fileName.
 *              The initial file size is of one page. This method fills
 *              this single page with '\0' bytes
 *
 * Parameter: fileName
 *
 * Return: RC Code
 -------------------------------------------------------------------------*/
extern RC createPageFile (char *fileName)
{
    char *memoryPointer;  //Memory pointer
    fp=fopen(fileName,"w");
    if(fp==NULL)
    {
        RC_message="File does not exists!";
        return RC_FILE_NOT_FOUND;
    }
    memoryPointer=(SM_PageHandle)calloc(PAGE_SIZE,sizeof(char));
    //writing from memory to file in binary mode.
    fwrite(memoryPointer,1,PAGE_SIZE,fp);
    free(memoryPointer);
    RC_message="File created successfully!";
    fclose(fp);//close the file.
    return RC_OK;
}

/*-----------------------------Open Page File-------------------------------------
 * Method Name: openPageFile
 *
 * Description: Opens an existing page file.
 *              Should return RC_FILE_NOT_FOUND if the file does not exist.
 *              The second parameter is an existing file handle.
 *              If opening the file is successful, then the fields of this file
 *              handle should be initialized with the information about the
 *              opened file.For instance, you would have to read the total number
 *              of pages that are stored in the file from disk.
 *
 * Parameter: char *fileName, SM_FileHandle *fHandle
 *
 * Return: RC Code
 ---------------------------------------------------------------------------------*/
extern RC openPageFile (char *fileName, SM_FileHandle *fHandle)
{
    FILE *fp;
    long size;
    if(!(fp=fopen(fileName,"r+")))
    {
        RC_message="File does not exists!";
        return RC_FILE_NOT_FOUND;
    }
    else
    {
        //move pointer at the end of the file.
        fseek(fp,0,SEEK_END);
        size=ftell(fp);  //tells the current position of the pointer in the file.
        int s=(int)size+1;
        fHandle->totalNumPages=s/PAGE_SIZE;
        fseek(fp,0,SEEK_SET);//move pointer back to begining
        fHandle->fileName=fileName;
        fHandle->curPagePos=0;  //Current page# starting with 0.
        fHandle->mgmtInfo=fp;
        RC_message="File opened successfully!";
        return RC_OK;
    }
}

/*--------------------------------Close Page File----------------------------
 * Method Name: closePageFile
 *
 * Description: this method close the page file
 *
 * Parameter: SM_FileHandle *fHandle
 *
 * Return: RC Code
 ---------------------------------------------------------------------------*/
extern RC closePageFile (SM_FileHandle *fHandle)
{
    if(fp==NULL)
    {
        fHandle=NULL;
        RC_message="File does not exists to close!";
        return RC_FILE_NOT_FOUND;
    }
    else
    {
        fHandle=NULL;
        fclose(fp);
        //fp=NULL;
        RC_message="File closed successfully!";
        return RC_OK;
    }
}

/*-------------------------------Destroy Page File-------------------------
 * Method Name: destroyPageFile
 *
 * Description: this method Destroy(delete) the page file
 *
 * Parameter: char *fileName
 *
 * Return: RC Code
 -------------------------------------------------------------------------*/
extern RC destroyPageFile (char *fileName)
{
    //Destroy or Delete file after it is compiled and executed
    remove(fileName);
    RC_message="File deleted successfully!";
    return RC_OK;
}

/*-------------------------------------Read Block------------------------------------
 * Method Name: readBlock
 *
 * Description: The method reads the pageNumth block from a file and stores
 *              its content in the memory pointed to by the memPage page handle.
 *              If the file has less than pageNum pages, the method should return
 *              RC_READ_NON_EXISTING_PAGE.
 *
 * Parameter: int pageNum: the number of the page that is about to read
 *              SM_FileHandle *fHandle: the file handler that contains the file info
 *              SM_PageHandle memPage: the page handler that points to the stream to
 *              be written to the file
 *
 * Return: RC Code
 ----------------------------------------------------------------------------------*/
extern RC readBlock (int pageNum, SM_FileHandle *fHandle, SM_PageHandle memPage)
{
    if(fHandle==NULL)
    {
        RC_message="No Data!";
        return RC_FILE_HANDLE_NOT_INIT;
    }
    else
    {
        //Total Pages greater than or equal to page number.
        //Page# starts with 0 in file.
        if(fHandle->totalNumPages>=(pageNum+1) && pageNum==0)
        {
            if(memPage!=NULL)
            {
                //Move the pointer position to the beginning of the file.
                fseek(fHandle->mgmtInfo,PAGE_SIZE*pageNum,SEEK_SET);
                fread(memPage,1,PAGE_SIZE,fHandle->mgmtInfo);  //file is read and written data into memory.
                fHandle->curPagePos=pageNum;
                RC_message="File content read successfully!";
                return RC_OK;
            }
            return RC_READ_FAILED;
        }
        else if(fHandle->totalNumPages>=(pageNum+1) && pageNum>0)
        {
            if(memPage!=NULL)
            {
                //Move the pointer position to the end of the file.
                //fseek(fHandle->mgmtInfo,(pageNum+1)*PAGE_SIZE,SEEK_SET) working;
                fseek(fHandle->mgmtInfo,(PAGE_SIZE)*pageNum,SEEK_SET);
                fread(memPage,1,PAGE_SIZE,fHandle->mgmtInfo);  //file is read and written data into memory.
                fHandle->curPagePos=pageNum;
                RC_message="File content read successfully!";
                return RC_OK;
            }
            return RC_READ_FAILED;
        }
        else
        {
            RC_message="Pages not found in the file!";
            return RC_READ_NON_EXISTING_PAGE;   //Total Pages less than page number.
        }
    }
}

/*----------------------------------Get Block Position-----------------------------
 * Method Name: getBlockPos
 *
 * Description: this method block returns the current Page Position in the
 *              structure being used to store the current page position.
 *
 * Parameter: SM_FileHandle *fHandle: the file handle that contains the file info
 *
 * Return: int
 --------------------------------------------------------------------------------*/
extern int getBlockPos (SM_FileHandle *fHandle)
{
    if(fHandle==NULL)
    {
        RC_message="No Data!";
        return RC_FILE_HANDLE_NOT_INIT;
    }
    else
    {
        return (fHandle->curPagePos);
    }
}

/*-----------------------------------Read First Block----------------------------
 * Method Name: readFirstBlock
 *
 * Description: Return the first page position of a file.
 *
 * Parameter: SM_FileHandle *fHandle: the file handle that contains the file info
 *              SM_PageHandle memPage: the page handler that points to the stream
 *              to be written to the file.
 *
 * Return: RC: return code
 -------------------------------------------------------------------------------*/
extern RC readFirstBlock (SM_FileHandle *fHandle, SM_PageHandle memPage)
{
    if(fHandle==NULL)
    {
        RC_message="No Data!";
        return RC_FILE_HANDLE_NOT_INIT;
    }
    else
    {
        return readBlock (0,fHandle,memPage);
    }
}

/*-----------------------------------Read Previous Block---------------------------
 * Method Name: readPreviousBlock
 *
 * Description: Read the previous page relative to the curPagePos of the file. The
 *              curPagePos should be moved to the page that was read. If the user
 *              tries to read a block before the first page of after the last page
 *              of the file, the method should return RC_READ_NON_EXISTING_PAGE
 *
 * Parameter:    SM_FileHandle *fHandle: the file handle that contains the file info
 *                SM_PageHandle memPage: the page handler that points to the stream to
 *                be written to the file
 *
 * Return: RC: return code
 ---------------------------------------------------------------------------------*/
extern RC readPreviousBlock (SM_FileHandle *fHandle, SM_PageHandle memPage)
{
    if(fHandle==NULL)
    {
        RC_message="No Data!";
        return RC_FILE_HANDLE_NOT_INIT;
    }
    else if(fHandle!=NULL && getBlockPos(fHandle)==0)
    {
        RC_message="No previous page available to read!";
        return RC_READ_NON_EXISTING_PAGE;
    }
    else if(fHandle!=NULL && getBlockPos(fHandle)>0)
    {
        return readBlock ((getBlockPos(fHandle)-1),fHandle,memPage);
    }
    else
    {
        RC_message="Can't perform reading of prvious block!";
        return RC_FAILED_OPERATION;
    }
}

/*---------------------------------Return Current Block------------------------
 * Method Name: readCurrentBlock
 *
 * Description: Read the current page relative to the curPagePos of the file.
 *              The curPagePos should be moved to the page that was read.
 *              If the user tries to read a block before the first page of
 *              after the last page of the file, the method should return
 *              RC_READ_NON_EXISTING_PAGE.
 *
 * Parameter:  SM_FileHandle *fHandle: the file handle that contains the file info
 *             SM_PageHandle memPage: the page handler that points to the stream
 *             to be written to the file
 *
 * Return: RC: return code
 -----------------------------------------------------------------------------*/
extern RC readCurrentBlock (SM_FileHandle *fHandle, SM_PageHandle memPage)
{
    if(fHandle==NULL)
    {
        RC_message="No Data!";
        return RC_FILE_HANDLE_NOT_INIT;
    }
    else if(fHandle!=NULL && getBlockPos(fHandle)>=0)
    {
        return readBlock (getBlockPos(fHandle),fHandle,memPage);
    }
    else
    {
        RC_message="No page to read!";
        return RC_READ_NON_EXISTING_PAGE;
    }
}

/*-------------------------------------Read Next Block------------------------------
 * Method Name: readNextBlock
 *
 * Description: Read the current, previous, or next page relative to the
 *              curPagePos of the file. The curPagePos should be moved to the
 *              page that was read. If the user tries to read a block before
 *              the first page of after the last page of the file, the method
 *              should return RC_READ_NON_EXISTING_PAGE.
 *
 * Parameter:  SM_FileHandle *fHandle: the file handle that contains the file info
 *             SM_PageHandle memPage: the page handler that points to the stream to
 *             be written to the file
 *
 * Return: RC: return code
 ------------------------------------------------------------------------------------*/
extern RC readNextBlock (SM_FileHandle *fHandle, SM_PageHandle memPage)
{
    if(fHandle==NULL)
    {
        RC_message="No Data!";
        return RC_FILE_HANDLE_NOT_INIT;
    }
    else if(fHandle!=NULL && fHandle->totalNumPages<=(getBlockPos(fHandle)+1))
    {
        RC_message="No page to read!";
        return RC_READ_NON_EXISTING_PAGE;
    }
    else
    {
        return readBlock (getBlockPos(fHandle)+1,fHandle,memPage);
    }
}

/*-------------------------------------Read Last Block--------------------------------
 * Method Name: readLastBlock
 *
 * Description: Read one page from the Next block.
 *
 * Parameter: SM_FileHandle *fHandle: the file handle that contains the file info
 *            SM_PageHandle memPage: the page handler that points to the stream to
 *            be written to the file
 *
 * Return: RC: return code
 -------------------------------------------------------------------------------------*/
extern RC readLastBlock (SM_FileHandle *fHandle, SM_PageHandle memPage)
{
    if(fHandle==NULL)
    {
        RC_message="No Data!";
        return RC_FILE_HANDLE_NOT_INIT;
    }
    else
    {
        return readBlock (fHandle->totalNumPages-1,fHandle,memPage);
    }
}

/*-------------------------------------Write Block----------------------------------
 * Method Name: writeBlock
 *
 * Description: this method block writes one page BACK to the disk(file) start
 *              from absolute position.
 *
 * Parameter:  int pageNum: the start point of the page number in the file
 *             SM_FileHandle *fHandle: the file handle that contains the file info
 *             SM_PageHandle memPage: the page handler that points to the stream to
 *             be written to the file
 *
 * Return: RC: return code
 -----------------------------------------------------------------------------------*/
extern RC writeBlock (int pageNum, SM_FileHandle *fHandle, SM_PageHandle memPage)
{
    if(fHandle==NULL)
    {
        RC_message="No Data!";
        return RC_FILE_HANDLE_NOT_INIT;
    }
    else
    {
        //Total Pages greater than or equal to page number.
        //Page# starts with 0 in file.
        if(fHandle->totalNumPages>pageNum && pageNum>=0)
        {
            if(memPage!=NULL)
            {
                //Move the pointer position to the beginning of the file.
                fseek(fHandle->mgmtInfo,((pageNum)*(PAGE_SIZE)*sizeof(char)),SEEK_SET);
                fwrite(memPage,1,PAGE_SIZE,fHandle->mgmtInfo);
                fHandle->curPagePos=pageNum;
                RC_message="File written successfully!";
                return RC_OK;
            }
            return RC_WRITE_FAILED;
        }
        else
        {
            RC_message="Pages not found in the file!";
            return RC_WRITE_FAILED;   //Total Pages less than page number then writing fails.
        }
    }
}

/*-------------------------------Write Current Block---------------------------------
 * Method Name: writeCurrentBlock
 *
 * Description: this method block writes one page BACK to the disk(file) start from
 *              current position.
 *
 * Parameter: SM_FileHandle *fHandle: the file handle that contains the file info
 *            SM_PageHandle memPage: the page handler that points to the stream to
 *            be written to the file
 *
 * Return: RC: return code
 ------------------------------------------------------------------------------------*/
extern RC writeCurrentBlock (SM_FileHandle *fHandle, SM_PageHandle memPage)
{
    if(fHandle==NULL)
    {
        RC_message="No Data!";
        return RC_FILE_HANDLE_NOT_INIT;
    }
    else
    {
        return writeBlock (getBlockPos(fHandle),fHandle,memPage);
    }
}

/*--------------------------------Append Empty Block----------------------------------
 * Method Name: appendEmptyBlock
 *
 * Description: this method block increase the number of pages in the file by one.
 *              The new last page should be filled with zero bytes.
 *
 * Parameter: SM_FileHandle *fHandle: the file handle that contains the file info
 *
 * Return: RC: return code
 ------------------------------------------------------------------------------------*/
extern RC appendEmptyBlock (SM_FileHandle *fHandle)
{
    FILE *fp=fHandle->mgmtInfo; //added
    char *memoryPointer;
    if(fHandle==NULL)
    {
        RC_message="No Data!";
        return RC_FILE_HANDLE_NOT_INIT;
    }
    else
    {
        //fp=fopen(fHandle->fileName,"a");
        fHandle->totalNumPages=fHandle->totalNumPages+1;
        //fseek(fp,(fHandle->totalNumPages)*PAGE_SIZE,SEEK_END); working
        fseek(fp,0,SEEK_END);
        memoryPointer=(char*)calloc(PAGE_SIZE,sizeof(char));
        //fwrite(memoryPointer,PAGE_SIZE,1,fp); working
        fwrite(memoryPointer,1,PAGE_SIZE,fHandle->mgmtInfo);
        fHandle->curPagePos=fHandle->totalNumPages-1;
        free(memoryPointer);
        RC_message="An empty block or page is succedsfully added in the file!";
        return RC_OK;
    }
}
/*---------------------------------------Ensure Capacity-------------------------------------
 * Function Name: ensureCapacity
 *
 * Description: If the file has less than numberOfPages pages then increase the size to numberOfPages.
 *
 * Parameters: int numberOfPages: the number of the pages that the file needs to be increased to
 *             SM_FileHandle *fHandle: the file handle that contains the file info
 *
 * Return: RC: return code
 -------------------------------------------------------------------------------------------*/
extern RC ensureCapacity (int numberOfPages, SM_FileHandle *fHandle)
{
    int x;
    if(fHandle==NULL)
    {
        RC_message="No Data!";
        return RC_FILE_HANDLE_NOT_INIT;
    }
    else if (numberOfPages<=fHandle->totalNumPages)
    {
        return RC_OK;
    }
    else
    {
        x=numberOfPages-fHandle->totalNumPages;
        for(int y=0;y<x;y++)
        {
            appendEmptyBlock(fHandle);
        }
        RC_message="File size has been increased successfully!";
        return RC_OK;
    }
}
